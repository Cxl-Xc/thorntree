package com.cxl.controller;


import com.cxl.entity.Po.CommentCategory;
import com.cxl.service.ICommentCategoryService;
import com.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class CommentCategoryController {

    @Resource
    private ICommentCategoryService iCommentCategoryService;

    //获取所有分类的名字  和帖子属于这个分类的数量
    @GetMapping("/selectAllCommentCategoryNameAndCounts")
    public Result selectAllCommentCategoryNameAndCounts(){

        //查询全部的分类
        List<CommentCategory> commentCategoryList=iCommentCategoryService.selectAllCommentCategory();

        //查询每个分类的帖子数量

        //查询爱情的帖子的数量
        List<Integer> aiQing = new ArrayList<>();
        aiQing.add(iCommentCategoryService.selectCountAiQing());
        //查询友情的帖子数量
        List<Integer> youQing = new ArrayList<>();
        youQing.add(iCommentCategoryService.selectCountYouQing());
        //查询亲情的帖子的数量
        List<Integer> qinQing = new ArrayList<>();
        qinQing.add(iCommentCategoryService.selectCountQinQing());

        //生成一个map用户存放
        Map<String, List> commentCategoryNameAndCounts = new LinkedHashMap<>();

        commentCategoryNameAndCounts.put("commentCategoryList", commentCategoryList);

        commentCategoryNameAndCounts.put("aiQing", aiQing);
        commentCategoryNameAndCounts.put("youQing", youQing);
        commentCategoryNameAndCounts.put("qinQing", qinQing);

        return new Result(12, "查询所有类别成功 返回各类别帖子数量", commentCategoryNameAndCounts);

    }
}
