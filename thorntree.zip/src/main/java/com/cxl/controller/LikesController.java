package com.cxl.controller;


import com.cxl.entity.Po.Likes;
import com.cxl.entity.Vo.LikesVo;
import com.cxl.service.ILikesService;
import com.cxl.service.IUserService;
import com.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class LikesController {

    @Resource
    private IUserService iUserService;

    @Resource
    private ILikesService iLikesService;

    //点赞接口
    @PostMapping("/likes")
    public Result likes(@RequestBody LikesVo likesVo) {

        //先查询token的值
        String token = iUserService.selectTokenByUserId(likesVo.getUserId());

        //判断token的值
        if (token.equals(likesVo.getToken())) {
            //先根据userId和commentId去likes表里查询是否已经点赞
            Likes likes = iLikesService.selectByUserIdAndCommentId(likesVo.getUserId(), likesVo.getCommentId());

            //根据查询到的值进行判断
            if (likes == null) {
                //空的 向likes表插入数据 并且实现comment表likes加1
                iLikesService.lieksByUserIdAndCommentId(likesVo.getUserId(), likesVo.getCommentId());
                return new Result(9, "点赞成功 之前未点赞",iLikesService.selectLikesByCommentId(likesVo.getCommentId()));

            } else {
                //有数据  说明已经有记录  判断state的值   如果是0代表点赞了 取消   如果是1代表取消赞 点赞
                if (likes.getState().equals("0")) {
                    //如果是0  则为点赞 取消点赞
                    iLikesService.updateLikesStateDownByLikesId(likes.getLikesId(), likes.getCommentId());
                    return new Result(10, "之前点赞过 取消点赞",iLikesService.selectLikesByCommentId(likesVo.getCommentId()));
                } else {
                    //如果是1  则为取消点赞   点赞
                    iLikesService.updateLikesStateUpByLikesId(likes.getLikesId(),likes.getCommentId());
                    return new Result(11,"之前是取消点赞 点赞",iLikesService.selectLikesByCommentId(likesVo.getCommentId()));
                }

            }


        } else {
            return new Result(-3, "登录失效 请重新登录");
        }
    }


}
