package com.cxl.controller;


import com.cxl.entity.Po.User;
import com.cxl.service.IUserPortraitAddressService;
import com.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class UserPortraitAddressController {

    @Resource
    private IUserPortraitAddressService iUserPortraitAddressService;

    //上传用户头像
    @PostMapping("/addUserPortrait")
    public Result upload(@RequestParam("userId") Integer userId,
                         @RequestParam("file") MultipartFile file
    ) throws Exception {


        //先根据userId到user表查询是否有此用户
        User user = iUserPortraitAddressService.selectByUserId(userId);

        if (user != null) {


            //        String path = "F:/image/" ;//保存到指定的文件目录
            //        String path = "/usr/local/img/" ;//保存到指定的文件目录
            //生成时间
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "thorntree/userAddress/" + userId + "/PortraitAddress" + df.format(new Date());//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            file.transferTo(new File(dir.getAbsolutePath() + File.separator + file.getOriginalFilename()));
            String name = "/" + path2 + "/" + file.getOriginalFilename();//获取图片的名字

            //插入头像地址
            iUserPortraitAddressService.updatePortraitAddress(userId, name);


            return new Result(6, "上传头像成功", name);


        } else {
            return new Result(-6, "上传头像失败 用户不存在");

        }


    }


}
