package com.cxl.controller;

import com.cxl.hander.GetDetailByUrl;
import com.cxl.utils.WeiXinViolationCheckUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.Map;
import java.util.concurrent.ExecutionException;

@RestController
@CrossOrigin
@RequiredArgsConstructor
@Api(tags = "文章图片检测是否违规")
public class SecurityCheckController {

    @Resource
    GetDetailByUrl getDetailByUrl;

    String APPID = "wx2bcb898c76a62fc6";
    String SECRET = "0f48216b3ec234095ecc357ac7f6c187";
    String GET_TOKEN = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid="+APPID+"&secret="+SECRET;
    static Long oldTime = 0L;
    static String tokenCache = "";
    // 过期时间,2h-1m
    static Long outTime = 7200000L - 60000;

    public @ResponseBody String getToken(){
        Long nowTime = System.currentTimeMillis();
        Long cacheTime = nowTime - oldTime;
        if (oldTime <=0 || cacheTime > outTime){
            RestTemplate restTemplate;
            restTemplate = new RestTemplate();
            String json = restTemplate.getForObject(GET_TOKEN, String.class);
            tokenCache = json.split("\"access_token\":\"")[1].split("\",\"")[0].trim();
            oldTime = System.currentTimeMillis();
            return tokenCache;
        }else {
            return tokenCache;
        }
    }

    @ApiOperation("检测文字或者图片是否存在违规")
//    @ApiImplicitParams({
//            @ApiImplicitParam(name = "content", value = "文字"),
//            @ApiImplicitParam(name = "file", value = "图片上传路径")
//    })
//
    @PostMapping("/checkImgOrMsg")
    public  Map check(@RequestParam(value = "file", required = false) MultipartFile file,
                                   @RequestParam(value = "content", required = false) String content) throws ExecutionException, InterruptedException {

        System.out.println(content);

            String token = getToken();

        return WeiXinViolationCheckUtil.checkImgOrMsg(file, content, token);
    }
}

