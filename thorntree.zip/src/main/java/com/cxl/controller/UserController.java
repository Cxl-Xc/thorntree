package com.cxl.controller;


import com.cxl.entity.Bo.LoginBo;
import com.cxl.entity.Dto.UserDto;
import com.cxl.entity.Po.User;
import com.cxl.entity.Vo.*;
import com.cxl.hander.GetDetailByUrl;
import com.cxl.hander.TokenUtil;
import com.cxl.service.IUserService;
import com.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;
import javax.mail.internet.MimeMessage;
import javax.security.auth.login.CredentialNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-12
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class UserController {

    @Resource
    private IUserService iUserService;

    @Resource
    TokenUtil tokenUtil;

    @Resource
    GetDetailByUrl getDetailByUrl;


    private final JavaMailSender mailSender; //注入QQ发送邮件的bean
    //校验验证码的正确性
    public static Integer verificationCode = 1;
    //校验验证码是否过期时间
    public static Integer verifcationTime = 0;

    //获取微信小程序服务端token接口测试
    @PostMapping("/getWxToken")
    public Result getWxToken(){


        return new Result(200, "获取token", getDetailByUrl.getDetailByUrl());

    }

    //微信授权登录  根据前端发送过来的code 查询到openid并返回
    @PostMapping("/wxLogin")
    public Result wxLogin(@RequestBody LoginBo loginBo) throws IOException {
        //打印获取的从微信小程序获取的code
        System.out.println(loginBo);


        String url = "https://api.weixin.qq.com/sns/jscode2session?appid=wx2bcb898c76a62fc6" +//appId
                "&secret=0f48216b3ec234095ecc357ac7f6c187" +//小程序密钥
                "&js_code="+loginBo.getCode()+
                "&grant_type=authorization_code";

        OkHttpClient client =new OkHttpClient();
        Request request = new Request.Builder().url(url).build();
        Response response = client.newCall(request).execute();

        if (response.isSuccessful()){
            String body = response.body().string();

            //{"session_key":"UAyJhPdA8kragG3fX5eFJw==","openid":"oI8Rx5GdyyTOK7iHZIipPn5ohuy8"}
            System.out.println(body);//查询到了openId

            //取出末尾的openId
            String openId=body.substring(body.length()-30, body.length());

            System.out.println(openId.substring(0, openId.length()-2));

            //取出openId
            String openId2=openId.substring(0, openId.length()-2);

            //根据openId去数据库里查询是否有这个账号  没有 注册账号 有 返回账号信息
            User user = iUserService.selectUserByOpenId(openId2);

            if (user==null){
                //为查询到账号 注册账号
                User user2 = new User();
                user2.setOpenId(openId2);
                Random rand = new Random();

                user2.setUsername("用户"+rand.nextInt(9999) );
                user2.setToken("diyicidengluToken");

                //根据openID插入账号
                Integer userId = iUserService.registerByOpenId(user2);
                System.out.println(userId);
                if (userId != null) {
                    //上传默认头像
                    iUserService.insertDefaultUserPortraitAddress(userId);
                    //插入用户权限
                    iUserService.insertDefaultUserRole(userId);

                }
                //查询账号的全部信息并返回
                User user3 = iUserService.selectUserByOpenId(openId2);
                UserDto userDto1=new UserDto();
                userDto1.setUserId(user3.getUserId());
                userDto1.setUsername(user3.getUsername());
                userDto1.setPassword(user3.getPassword());
                userDto1.setState(user3.getState());
                userDto1.setEmail(user3.getEmail());
                userDto1.setToken(user3.getToken());
                userDto1.setOpenId(user3.getOpenId());
                //获取头像
                userDto1.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(user3.getUserId()));
                //获取权限
                userDto1.setUserRole(iUserService.selectUserRoleByUserId(user3.getUserId()));
                return new Result(200, "授权登录成功 新账号",userDto1);
            }else{
                //返回用户信息 返回token
                //生成token 插入
                User user1 = new User();
                user1.setUserId(user.getUserId());
                user1.setUsername(user.getUsername());
                user1.setPassword(user.getPassword());
                String token = tokenUtil.generateToken(user1);

                //根据userId插入token
                iUserService.updateUserToken(user.getUserId(), token);

                //返回账号的全部信息
                UserDto userDto1 = new UserDto();
                userDto1.setUserId(user.getUserId());
                userDto1.setUsername(user.getUsername());
                userDto1.setPassword(user.getPassword());
                userDto1.setState(user.getState());
                userDto1.setEmail(user.getEmail());
                userDto1.setToken(token);
                userDto1.setOpenId(user.getOpenId());
                //获取头像
                userDto1.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(user.getUserId()));
                //获取权限
                userDto1.setUserRole(iUserService.selectUserRoleByUserId(user.getUserId()));

                return new Result(300, "授权登录成功 已有账号", userDto1);

            }





        }




        return new Result(200, "微信授权登录");



    }



    //查询全部用户权限为user的用户
    @GetMapping("/selectAllRoleByUser")
    public Result selectAllRoleByUser(@RequestParam Integer page){
        //查询全部权限为user的用户id
        List<Integer> userIdList=iUserService.selectAllRoleByUser(page);

        List<UserDto> userList = new ArrayList<>();
        for (int i = 0; i <=userIdList.size()-1 ; i++) {
            userList.add(iUserService.selectUserByUserId(userIdList.get(i)));
        }

        userList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //查询总条数
        List<Integer> counts = new ArrayList<>();
        counts.add(iUserService.selectCountByUser());

        Map<String, List> userAndCounts = new LinkedHashMap<>();
        userAndCounts.put("userList", userList);
        userAndCounts.put("counts", counts);


        if (userIdList.size() < 10) {

            return new Result(13, "查询成功 已是最后一页",userAndCounts);

        }else{
            return new Result(14, "查询成功 不是最后一页", userAndCounts);
        }
    }



    //更改用户名
    @PostMapping("/changeUserName")
    public Result changeUserName(@RequestBody UserVo1 userVo1) {
        //先根据newUsername查询是否已经有这个名字
        User user = iUserService.selectUserByUsername(userVo1.getNewUsername());
        //先去判断token的值
        String token = iUserService.selectTokenByUserId(userVo1.getUserId());

        if (token.equals(userVo1.getToken())) {
            if (user != null) {
                return new Result(-13, "修改用户名失败 用户名已经存在");
            }else{
                //说名用户名不存在  修改用户名
                iUserService.changeUserName(userVo1.getUserId(), userVo1.getNewUsername());
                return new Result(25, "修改用户名成功", userVo1.getNewUsername());
            }
        }else{
            return new Result(-3, "登录失效 请重新登录");
        }

    }




    //第三步 修改密码
    @PostMapping("/changePassword")
    public Result changePassword(@RequestBody UserForgetPasswordVo ufpv) {
        //直接修改密码
        iUserService.updateUserPassword(ufpv.getUserId(), ufpv.getNewPassword());
        return new Result(20, "修改密码成功");

    }


    //第二步 点击下一步 判断验证码是否过期或相同
    @PostMapping("/verifyVerificationCodeAndVerifcationTime")
    public Result verifyVerificationCodeAndVerifcationTime(@RequestBody VerifyVerificationCodeVo vvcv) {
        //判断验证码是否已经过期
        SimpleDateFormat df = new SimpleDateFormat("MMddHHmm");
        Integer verifcationTime2 = Integer.parseInt(df.format(new Date()));
        Integer verifcationTime3 = verifcationTime2 - verifcationTime;

        if (verifcationTime3 >= 3) {
            return new Result(-7, "验证码失效 请重新发送");
        }else{
            if (vvcv.getMsg().equals(verificationCode)) {
                //根据邮箱查询账号
                User user = iUserService.selectUserByEmail(vvcv.getEmail());
                return new Result(21, "验证码正确 下一步", user.getUserId());
            }else{
                return new Result(-4, "验证码错误 请重新输入");
            }
        }
    }


    //第一步 忘记密码前置  校验邮箱 发送验证码
    @PostMapping("/verifyEmailAndSendEmail")
    public Result verifyEmailAndSendEmail(@RequestParam String email) {

        //判断邮箱是否绑定账号
        User user = iUserService.selectUserByEmail(email);
        if (user == null) {
            return new Result(-12, "账号不存在");
        } else {
            //说明数据库里有这个账号绑定这个邮箱
            //发送验证码  返回userId
            try {

                MimeMessage mimeMessage = this.mailSender.createMimeMessage();
                MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
                message.setFrom("chenxiaoli0111@qq.com");//设置发件qq邮箱

                message.setTo(email);    //设置收件人
                message.setSubject("验证码");//设置标题

                //随机生成4位验证码
                Random r = new Random();
                verificationCode = r.nextInt(8000) + 1999;


                message.setText("你更改密码的的验证码是:" + verificationCode + "  有效时间为3分钟");    //第二个参数true表示使用HTML语言来编写邮件
                this.mailSender.send(mimeMessage);
                SimpleDateFormat df = new SimpleDateFormat("MMddHHmm");

                //绑定校验时间
                verifcationTime = Integer.parseInt(df.format(new Date()));

                return new Result(5, "发送验证码成功");

            } catch (Exception e) {

                return new Result(-5, "发送验证码失败");
            }
        }
    }


    //账号注册
    @PostMapping("/register")
    public Result register(@RequestBody User user) {

        //用户名不能相同 先根据username查询是否已存在账号
        User userDto = iUserService.selectUserByUsername(user.getUsername());

        //判断userDto的值
        if (userDto == null) {
            //判断为空 说明账号没注册 注册账号
            Integer userId = iUserService.register(user);
            //判断是否已经注册成功
            if (userId != null) {
                //成功注册 上传默认头像
                iUserService.insertDefaultUserPortraitAddress(userId);
                //插入用户权限
                iUserService.insertDefaultUserRole(userId);
            }

            return new Result(1, "注册成功", user.getUsername());


        } else {
            //判断不为空 不能注册账号
            return new Result(-1, "账号已经注册 请勿重新注册");

        }

    }

    //账号登录
    @PostMapping("/login")
    public Result login(@RequestBody UserVo userVo) {

        //根据账号密码判断账号是否存在
        User userDto = iUserService.selectUserByUsernameAndPassword(userVo.getUsername(), userVo.getPassword());

        //判断userDto是否为空
        if (userDto == null) {

            //判断为空 返回账号或者密码错误
            return new Result(-2, "账号或者密码错误");

        } else {
            //生成token 插入
            User user = new User();
            user.setUserId(userDto.getUserId());
            user.setUsername(userVo.getUsername());
            user.setPassword(userVo.getPassword());
            String token = tokenUtil.generateToken(user);

            //根据userId插入token
            iUserService.updateUserToken(userDto.getUserId(), token);

            //返回账号的全部信息
            UserDto userDto1 = new UserDto();
            userDto1.setUserId(userDto.getUserId());
            userDto1.setUsername(userDto.getUsername());
            userDto1.setPassword(userDto.getPassword());
            userDto1.setState(userDto.getState());
            userDto1.setEmail(userDto.getEmail());
            userDto1.setToken(token);
            //获取头像
            userDto1.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(userDto.getUserId()));
            //获取权限
            userDto1.setUserRole(iUserService.selectUserRoleByUserId(userDto.getUserId()));

            return new Result(2, "登录成功", userDto1);
        }
    }

    //账号删除
    @PostMapping("/updateUserState")
    private Result updateUserState(@RequestBody UserUpdateStateVo userUpdateStateVo) {

        //先去判断token的值
        String token = iUserService.selectTokenByUserId(userUpdateStateVo.getAdminUserId());

        //判断token的值
        if (token.equals(userUpdateStateVo.getToken())) {
            //删除用户
            iUserService.updateUserState(userUpdateStateVo.getUpdateUserId());
            //删除用户权限
            iUserService.deleteUserRole(userUpdateStateVo.getUpdateUserId());
            return new Result(3, "删除用户成功");
        } else {
            return new Result(-3, "登录失效 请重新登录");
        }

    }

    //绑定邮箱
    @PostMapping("/bindingEmail")
    public Result bindingEmail(@RequestBody UserBindingEmailVo userBindingEmailVo) {

        //先去判断token的值
        String token = iUserService.selectTokenByUserId(userBindingEmailVo.getUserId());

        //判断token的值
        if (token.equals(userBindingEmailVo.getToken())) {

            //判断邮箱是否已经注册过
            User user = iUserService.selectUserByEmail(userBindingEmailVo.getEmail());

            if (user == null) {
                //判断验证码是否已经过期
                SimpleDateFormat df = new SimpleDateFormat("MMddHHmm");
                Integer verifcationTime2 = Integer.parseInt(df.format(new Date()));
                Integer verifcationTime3 = verifcationTime2 - verifcationTime;

                if (verifcationTime3 >= 3) {
                    return new Result(-7, "验证码失效 请重新发送");
                } else {
                    if (userBindingEmailVo.getMsg().equals(verificationCode)) {
                        //验证码正确 插入邮箱
                        iUserService.updateUserEmailByUserId(userBindingEmailVo.getUserId(), userBindingEmailVo.getEmail());
                        return new Result(4, "绑定邮箱成功");

                    } else {
                        return new Result(-4, "验证码错误 请重新输入");
                    }
                }
            } else {
                return new Result(-11, "绑定邮箱失败 该邮箱已经绑定");
            }


        } else {
            return new Result(-3, "登录失效 请重新登录");
        }

    }


    //输入邮箱 发送验证码
    @GetMapping("/sendEmail")
    public Result sendEmail(@RequestParam String email) {


        try {

            MimeMessage mimeMessage = this.mailSender.createMimeMessage();
            MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
            message.setFrom("chenxiaoli0111@qq.com");//设置发件qq邮箱


            message.setTo(email);    //设置收件人
            message.setSubject("验证码");//设置标题

            //随机生成4位验证码
            Random r = new Random();
            verificationCode = r.nextInt(8000) + 1999;


            message.setText("你更改密码的的验证码是:" + verificationCode + "  有效时间为3分钟");    //第二个参数true表示使用HTML语言来编写邮件
            this.mailSender.send(mimeMessage);
            SimpleDateFormat df = new SimpleDateFormat("MMddHHmm");

            //绑定校验时间
            verifcationTime = Integer.parseInt(df.format(new Date()));

            return new Result(5, "发送验证码成功");

        } catch (Exception e) {

            return new Result(-5, "发送验证码失败");


        }


    }


}
