package com.cxl.controller;


import com.cxl.entity.Po.UserFeedBack;
import com.cxl.service.IUserFeedBackService;
import com.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2023-03-13
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class UserFeedBackController {
    @Resource
    private IUserFeedBackService iUserFeedBackService;

//    //用户反馈
    @PostMapping("/userFeedBack")
    public Result userFeedBack(@RequestBody UserFeedBack userFeedBack) {

        return new Result(400,"反馈成功",
                iUserFeedBackService.insertFeedBackByUserId(userFeedBack));


    }
}
