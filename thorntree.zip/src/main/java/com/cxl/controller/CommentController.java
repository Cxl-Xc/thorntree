package com.cxl.controller;


import com.cxl.entity.Dto.CommentDot1;
import com.cxl.entity.Dto.CommentDto;
import com.cxl.entity.Po.Comment;
import com.cxl.entity.Po.User;
import com.cxl.entity.Vo.*;
import com.cxl.service.ICommentService;
import com.cxl.service.IUserService;
import com.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class CommentController {

    @Resource
    private ICommentService iCommentService;

    @Resource
    private IUserService iUserService;






    //根据commentId查询下架帖子的全部信息
    @PostMapping("/selectCommentByCommentIdAndStateIs2")
    public Result selectCommentByCommentIdAndStateIs2(@RequestBody CommentVo commentVo) {
        //根据commentId查询comment
        List<CommentDto> commentDtoList = iCommentService.selectCommentByCommentIdAndStateIs2(commentVo.getCommentId());
        //给每个查询到的帖子的commendAddress赋值
        commentDtoList.forEach(i -> i.setCommentAddress(iCommentService.selectCommentAddress(i.getCommentId())));
        //给每个查询到的帖子的username赋值
        commentDtoList.forEach(i -> i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
        //给每个查询到的帖子的commentCategoryName赋值
        commentDtoList.forEach(i -> i.setCommentCategoryName(iCommentService.selectCommentCategoryNameBycommentCategoryId(i.getCommentCategoryId())));
        //给每个查询到的数据的userPortraitAddress赋值
        commentDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //查询该登录的账号点赞的帖子
        List<Integer> likes = iCommentService.selectUserLikeCommentId(commentVo.getUserId());

        Map<String, List> comment = new LinkedHashMap<>();
        comment.put("commentDtoList", commentDtoList);
        comment.put("likes", likes);

        return new Result(19, "根据帖子Id查询帖子成功", comment);
    }
    //根据commentId查询帖子likes comments  saw
    @GetMapping("/selectLikesAndCommentsAndSawByCommentId")
    public Result selectLikesAndCommentsAndSawByCommentId(@RequestParam Integer commentId) {
        CommentDot1 commentDot1 = iCommentService.selectLikesAndCommentsAndSawByCommentId(commentId);

        return new Result(30, "查询帖子评论数，点赞数，浏览量成功", commentDot1);

    }


    //查询全部下架的帖子 分页显示
    @GetMapping("/selectCommentByStateIs2")
    public Result selectCommentByStateIs2(@RequestParam Integer page) {

        //查询全部下架帖子  分页显示
        List<CommentDto> commentDtoList = iUserService.selectCommentByStateIs2(page);
        //给每个查询到的帖子的commendAddress赋值
        commentDtoList.forEach(i -> i.setCommentAddress(iCommentService.selectCommentAddress(i.getCommentId())));
        //给每个查询到的帖子的username赋值
        commentDtoList.forEach(i -> i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
        //给每个查询到的帖子的commentCategoryName赋值
        commentDtoList.forEach(i -> i.setCommentCategoryName(iCommentService.selectCommentCategoryNameBycommentCategoryId(i.getCommentCategoryId())));
        //给每个查询到的数据的userPortraitAddress赋值
        commentDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //查询全部下架帖子的数量
        List<Integer> counts = new ArrayList<>();
        counts.add(iCommentService.selectCounts());

        Map<String, List> countsAndComment = new LinkedHashMap<>();
        countsAndComment.put("commentDtoList", commentDtoList);
        countsAndComment.put("counts", counts);

        if (commentDtoList.size() < 10) {
            return new Result(13, "查询成功已是最后一页", countsAndComment);
        } else {
            return new Result(14, "查询成功 不是最后一页", countsAndComment);
        }
    }


    //管理员上架帖子
    @PostMapping("/unDeleteCommentIdByAdminUserId")
    public Result unDeleteCommentIdByAdminUserId(@RequestBody CommentVo1 commentVo1) {


        //先根据userid到comment表查询token的值
        String token2 = iUserService.selectTokenByUserId(commentVo1.getUserId());

        if (token2.equals(commentVo1.getToken())) {

            //修改帖子的state为0
            iCommentService.updateCommentStateByTo0(commentVo1.getCommentId());

            return new Result(29, "上架成功");

        } else {
            return new Result(-3, "登录失效，请重新登录");
        }

    }



    //管理员下架帖子
    @PostMapping("/deleteCommentIdByAdminUserId")
    public Result deleteCommentIdByAdminUserId(@RequestBody CommentVo1 commentVo1) {


        //先根据userid到comment表查询token的值
        String token2 = iUserService.selectTokenByUserId(commentVo1.getUserId());

        if (token2.equals(commentVo1.getToken())) {

            //修改帖子的state为2
            iCommentService.updateCommentStateByTo2(commentVo1.getCommentId());

            //修改这个帖子下的likes表的state为1
            iCommentService.updateLikesStateByCommentId(commentVo1.getCommentId());

            return new Result(28, "下架成功");

        } else {
            return new Result(-3, "登录失效，请重新登录");
        }

    }

    //根据commentId查询帖子的全部信息
    @PostMapping("/selectCommentByCommentId")
    public Result selectCommentByCommentId(@RequestBody CommentVo commentVo){
        //根据commentId查询comment
        List<CommentDto> commentDtoList = iCommentService.selectCommentByCommentId(commentVo.getCommentId());
        //给每个查询到的帖子的commendAddress赋值
        commentDtoList.forEach(i -> i.setCommentAddress(iCommentService.selectCommentAddress(i.getCommentId())));
        //给每个查询到的帖子的username赋值
        commentDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
        //给每个查询到的帖子的commentCategoryName赋值
        commentDtoList.forEach(i -> i.setCommentCategoryName(iCommentService.selectCommentCategoryNameBycommentCategoryId(i.getCommentCategoryId())));
        //给每个查询到的数据的userPortraitAddress赋值
        commentDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //查询该登录的账号点赞的帖子
        List<Integer> likes = iCommentService.selectUserLikeCommentId(commentVo.getUserId());

        Map<String, List> comment = new LinkedHashMap<>();
        comment.put("commentDtoList", commentDtoList);
        comment.put("likes", likes);

        return new Result(19, "根据帖子Id查询帖子成功", comment);
    }

    //用户自己删除帖子
    @PostMapping("/updateCommentStateByUserId")
    public Result updateCommentStateByUserId(@RequestBody CommentDeleteVo commentDeleteVo) {
        //判断token是否失效
        String token1 = iUserService.selectTokenByUserId(commentDeleteVo.getUserId());

        //判断token的值
        if (token1.equals(commentDeleteVo.getToken())) {
            //用户删除帖子
            iCommentService.updateCommentStateByUserId(commentDeleteVo.getUserId(), commentDeleteVo.getCommentId());
            //删除帖子下面的评论
            iCommentService.updateCommentSonStateByCommentId(commentDeleteVo.getCommentId());
            //删除全部点赞这个帖子的点赞
            iCommentService.updateLikesByCommentId(commentDeleteVo.getCommentId());
            return new Result(22, "删除帖子成功");

        }else{

            return new Result(-3, "登录失效 请重新登录");
        }

    }


    //根据用户喜欢查询帖子 分页显示
    @PostMapping("/selectCommentByLikesAndPage")
    public Result selectCommentByLikesAndPage(@RequestBody SelectAllCommentByPageVo sacbpv){
        //根据用户喜欢去查询帖子 第一步  根据用户的userId去查看他喜欢的帖子的Id  分页显示
        List<Integer> likesList = iCommentService.selectLikeCommentByUserId(sacbpv.getUserId(),sacbpv.getPage());

        //根据查询到的commentId去comment表查询全部信息
        List<CommentDto> commentDtoList=new ArrayList<>();
        for (int i = 0; i < likesList.size(); i++) {
            commentDtoList.add(iCommentService.selectCommentByCommentIdForLikes(likesList.get(i)));
        }
        //给每个查询到的帖子的username赋值
        commentDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
        //给每个查询到的帖子的commendAddress赋值
        commentDtoList.forEach(i -> i.setCommentAddress(iCommentService.selectCommentAddress(i.getCommentId())));
        //给每个查询到的帖子的commentCategoryName赋值
        commentDtoList.forEach(i -> i.setCommentCategoryName(iCommentService.selectCommentCategoryNameBycommentCategoryId(i.getCommentCategoryId())));
        //给每个查询到的数据的userPortraitAddress赋值
        commentDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //查询该登录的账号点赞的帖子
        List<Integer> likes = iCommentService.selectUserLikeCommentId(sacbpv.getUserId());
        //根据userid查询全部喜欢的帖子的数量
        List<Integer> counts = new ArrayList<>();
        counts.add(iCommentService.selectCountCommentByUserIdLike(sacbpv.getUserId()));

        Map<String, List> commentAndUserLikesAndCounts = new LinkedHashMap<>();
        commentAndUserLikesAndCounts.put("commentDtoList", commentDtoList);
        commentAndUserLikesAndCounts.put("likes", likes);
        commentAndUserLikesAndCounts.put("counts", counts);

        if (commentDtoList.size() < 10) {

            return new Result(13, "查询成功已是最后一页", commentAndUserLikesAndCounts);

        } else {

            return new Result(14, "查询成功 不是最后一页", commentAndUserLikesAndCounts);

        }



    }



    //根据用户Id查询帖子 分页显示
    @PostMapping("/selectCommentByUserIdAndPage")
    public Result selectCommentByUserIdAndPage(@RequestBody SelectAllCommentByPageVo sacbpv) {
        //根据userId查询该用户发布的帖子 分页显示
        List<CommentDto> commentDtoList = iCommentService.selectCommentByUserIdAndPage(sacbpv.getUserId(), sacbpv.getPage());
        //给每个查询到的帖子的username赋值
        commentDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
        //给每个查询到的帖子的commendAddress赋值
        commentDtoList.forEach(i -> i.setCommentAddress(iCommentService.selectCommentAddress(i.getCommentId())));
        //给每个查询到的帖子的commentCategoryName赋值
        commentDtoList.forEach(i -> i.setCommentCategoryName(iCommentService.selectCommentCategoryNameBycommentCategoryId(i.getCommentCategoryId())));
        //给每个查询到的数据的userPortraitAddress赋值
        commentDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //查询该登录的账号点赞的帖子
        List<Integer> likes = iCommentService.selectUserLikeCommentId(sacbpv.getUserId());
        //根据userId查询全部的帖子的数量
        List<Integer> counts = new ArrayList<>();
        counts.add(iCommentService.selectCountCommentByUserId(sacbpv.getUserId()));

        Map<String, List> commentAndUserLikesAndCounts = new LinkedHashMap<>();
        commentAndUserLikesAndCounts.put("commentDtoList", commentDtoList);
        commentAndUserLikesAndCounts.put("likes", likes);
        commentAndUserLikesAndCounts.put("counts", counts);

        if (commentDtoList.size() < 10) {

            return new Result(13, "查询成功已是最后一页", commentAndUserLikesAndCounts);

        } else {

            return new Result(14, "查询成功 不是最后一页", commentAndUserLikesAndCounts);

        }

    }

    //like查询帖子 分页显示
    @PostMapping("/selectCommentByLikeTitleAndPage")
    public Result selectCommentByLikeTitleAndPage(@RequestBody SelectCommentByLikeTitleAndPageVo scbltap) {

        //根据commentTitle查询全部帖子 分页显示
        List<CommentDto> commentDtoList = iCommentService.selectCommentByLikeTitleAndPage(scbltap.getCommentTitle(), scbltap.getPage());
        //给每个查询到的帖子的username赋值
        commentDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
        //给每个查询到的帖子的commendAddress赋值
        commentDtoList.forEach(i -> i.setCommentAddress(iCommentService.selectCommentAddress(i.getCommentId())));
        //给每个查询到的帖子的commentCategoryName赋值
        commentDtoList.forEach(i -> i.setCommentCategoryName(iCommentService.selectCommentCategoryNameBycommentCategoryId(i.getCommentCategoryId())));
        //给每个查询到的数据的userPortraitAddress赋值
        commentDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //查询该登录的账号点赞的帖子
        List<Integer> likes = iCommentService.selectUserLikeCommentId(scbltap.getUserId());
        //根据commentTitle查询全部的帖子的数量
        List<Integer> counts = new ArrayList<>();
        counts.add(iCommentService.selectCountCommentByLikeCommentTitle(scbltap.getCommentTitle()));

        Map<String, List> commentAndUserLikesAndCounts = new LinkedHashMap<>();
        commentAndUserLikesAndCounts.put("commentDtoList", commentDtoList);
        commentAndUserLikesAndCounts.put("likes", likes);
        commentAndUserLikesAndCounts.put("counts", counts);

        if (commentDtoList.size() < 10) {

            return new Result(13, "查询成功已是最后一页", commentAndUserLikesAndCounts);

        } else {

            return new Result(14, "查询成功 不是最后一页", commentAndUserLikesAndCounts);

        }

    }


    //分类查询帖子 分页显示
    @PostMapping("/selectCommentByCommentCategoryAndPage")
    public Result selectCommentByCommentCategoryAndPage(@RequestBody SelectCommentByCommentCategoryAndPageVo scbccap) {
        //根据类别查询帖子 分页显示
        //先根据commentCategoryName查询是否有这个类
        Integer commentCategoryId = iCommentService.selectCommentCategoryIdByCommentCategoryName(scbccap.getCommentCategoryName());
        if (commentCategoryId == null) {
            return new Result(-9, "查询失败 未找到该类");
        } else {
            //有值 说明有该类  根据类别查询帖子
            List<CommentDto> commentDtoList = iCommentService.selectCommentByCommentCategoryIdAndPage(scbccap.getPage(), commentCategoryId);
            //给每个查询到的帖子的username赋值
            commentDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
            //给每个查询到的帖子的commendAddress赋值
            commentDtoList.forEach(i -> i.setCommentAddress(iCommentService.selectCommentAddress(i.getCommentId())));
            //给每个查询到的帖子的commentCategoryName赋值
            commentDtoList.forEach(i -> i.setCommentCategoryName(iCommentService.selectCommentCategoryNameBycommentCategoryId(i.getCommentCategoryId())));
            //给每个查询到的数据的userPortraitAddress赋值
            commentDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
            //查询该登录的账号点赞的帖子
            List<Integer> likes = iCommentService.selectUserLikeCommentId(scbccap.getUserId());

            //查询全部类别的帖子的数量
            List<Integer> counts = new ArrayList<>();
            counts.add(iCommentService.selectCountCommentByCommentCategoryId(commentCategoryId));

            Map<String, List> commentAndUserLikesAndCounts = new LinkedHashMap<>();
            commentAndUserLikesAndCounts.put("commentDtoList", commentDtoList);
            commentAndUserLikesAndCounts.put("likes", likes);
            commentAndUserLikesAndCounts.put("counts", counts);

            if (commentDtoList.size() < 10) {

                return new Result(13, "查询成功已是最后一页", commentAndUserLikesAndCounts);

            } else {

                return new Result(14, "查询成功 不是最后一页", commentAndUserLikesAndCounts);

            }

        }
    }


    //查询全部的帖子 分页显示
    @PostMapping("/selectAllCommentByPage")
    public Result selectAllCommentByPage(@RequestBody SelectAllCommentByPageVo selectAllCommentByPageVo) {
        //查询全部的帖子  分页显示
        List<CommentDto> commentDtoList = iCommentService.selectAllCommentByPage(selectAllCommentByPageVo.getPage());
        //给每个查询到的帖子的username赋值
        commentDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
        //给每个查询到的帖子的commendAddress赋值
        commentDtoList.forEach(i -> i.setCommentAddress(iCommentService.selectCommentAddress(i.getCommentId())));
        //给每个查询到的帖子的commentCategoryName赋值
        commentDtoList.forEach(i -> i.setCommentCategoryName(iCommentService.selectCommentCategoryNameBycommentCategoryId(i.getCommentCategoryId())));
        //给每个查询到的数据的userPortraitAddress赋值
        commentDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //查询该登录的账号点赞的帖子
        List<Integer> likes = iCommentService.selectUserLikeCommentId(selectAllCommentByPageVo.getUserId());

        //查询全部的帖子的数量
        List<Integer> counts = new ArrayList<>();
        counts.add(iCommentService.selectCountComment());

        Map<String, List> commentAndUserLikesAndCounts = new LinkedHashMap<>();
        commentAndUserLikesAndCounts.put("commentDtoList", commentDtoList);
        commentAndUserLikesAndCounts.put("likes", likes);
        commentAndUserLikesAndCounts.put("counts", counts);

        if (commentDtoList.size() < 10) {

            return new Result(13, "查询成功已是最后一页", commentAndUserLikesAndCounts);

        } else {

            return new Result(14, "查询成功 不是最后一页", commentAndUserLikesAndCounts);

        }

    }


    //按照分类上传帖子  后置
    @PostMapping("/commentWithOutAddressHouZhi")
    public Result commentWithOutAddressHouZhi(@RequestParam Integer commentId,
                          @RequestParam MultipartFile commentAddress

    ) throws IOException {

                //        String path = "F:/image/" ;//保存到指定的文件目录
                //        String path = "/usr/local/img/" ;//保存到指定的文件目录
                //生成时间
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

                String path = "/home/image/";//保存到指定的文件目录
                String path2 = "thorntree/comment/" + commentId + "/commentAddress" + df.format(new Date());//保存到指定的文件目录
                File dir = new File(path + path2);
                if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                    dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
                }

                commentAddress.transferTo(new File(dir.getAbsolutePath() + File.separator + commentAddress.getOriginalFilename()));
                String name = "/" + path2 + "/" + commentAddress.getOriginalFilename();//获取图片的名字

                //向commentAddress插入图片地址
                iCommentService.insertIntoCommentAddress(commentId, name);

                return new Result(7, "上传帖子后置成功");

    }

    //按照分类上传帖子 前置
    @PostMapping("/commentWithOutAddressQianZhi")
    public Result commentWithOutAddressQianZhi(@RequestParam Integer userId,
                          @RequestParam String commentTitle,
                          @RequestParam String commentText,
                          @RequestParam String commentCategoryName,
                          @RequestParam String token
    ) throws IOException {

        //判断token是否失效
        String token1 = iUserService.selectTokenByUserId(userId);

        if (token.equals(token1)) {
            //先查询是否有这个类别
            Integer commentCategoryId = iCommentService.selectCommentCategoryIdByCommentCategoryName(commentCategoryName);

            if (commentCategoryId != null) {
                //找到了  上传图片 插入数据

                //插入comment
                Comment comment = new Comment();
                comment.setUserId(userId);
                comment.setCommentTitle(commentTitle);
                comment.setCommentText(commentText);
                comment.setCommentTime(new Date());
                comment.setLikes("0");
                comment.setSaw("0");
                comment.setComments("0");
                comment.setState("0");
                comment.setCommentCategoryId(commentCategoryId);
                //向comment插入数据
                iCommentService.insertIntoComment(comment);

                return new Result(18, "上传帖子前置成功",comment.getCommentId());

            } else {
                return new Result(-8, "上传帖子失败 未找到该类别");
            }
        } else {
            return new Result(-3, "登录失效 请重新登录");
        }


    }


}
