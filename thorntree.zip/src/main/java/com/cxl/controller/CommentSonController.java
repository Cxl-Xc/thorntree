package com.cxl.controller;


import com.cxl.entity.Dto.CommentSonDto;
import com.cxl.entity.Po.Comment;
import com.cxl.entity.Po.CommentSon;
import com.cxl.entity.Vo.CommentSonVo;
import com.cxl.entity.Vo.CommentSonVo1;
import com.cxl.entity.Vo.CommentSonVo2;
import com.cxl.service.ICommentSonService;
import com.cxl.service.IUserService;
import com.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class CommentSonController {

    @Resource
    private ICommentSonService iCommentSonService;

    @Resource
    private IUserService iUserService;



//    //根据帖子Id查询下架帖子下的评论
//    @PostMapping("/selectStateIs2CommentSonByCommentId")
//    public Result selectStateIs2CommentSonByCommentId(@RequestBody CommentSonVo1 commentSonVo1) {
//        //根据commentId查询到评论
//        List<CommentSonDto> commentSonDtoList = iCommentSonService.
//                selectStateIs2CommentSonByCommentId(commentSonVo1.getCommentId());
//        if (commentSonDtoList.isEmpty()) {
//            //将comment表的saw加1
//            iCommentSonService.updateCommentSawUp(commentSonVo1.getCommentId());
//            return new Result(-10, "暂无评论");
//        }else {
//            //给每个查询到的帖子的username赋值
//            commentSonDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
//            //设置头像
//            commentSonDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
//            //将comment表的saw加1
//            iCommentSonService.updateCommentSawUp(commentSonVo1.getCommentId());
//            //查询总评论数
//            List<Integer> counts=new ArrayList<>();
//            counts.add(iCommentSonService.selectCountCommentSonByCommentId(commentSonVo1.getCommentId()));
//            Map<String,List> commentSonAndCounts=new LinkedHashMap<>();
//            commentSonAndCounts.put("commentSonDtoList", commentSonDtoList);
//            commentSonAndCounts.put("counts",counts);
//
//            return new Result(14, "查询评论成功", commentSonAndCounts);
//
//        }
//    }

    //删除评论 根据commentSonId删除 管理员和普通用户都可以使用
    @PostMapping("/updateCommentSonStateByCommentSonId")
    public Result updateCommentSonStateByCommentSonId(@RequestBody CommentSonVo2 commentSonVo2){
        //判断token是否失效
        String token1 = iUserService.selectTokenByUserId(commentSonVo2.getUserId());

        if (token1.equals(commentSonVo2.getToken())) {

            //删除评论
            iCommentSonService.updateCommentSonStateByCommentSonId(commentSonVo2.getCommentSonId());
            //将comment表的comments-1
            iCommentSonService.updateCommentSetCommentsDownByCommentId
                    (iCommentSonService.selectCommentIdByCommentSonId(commentSonVo2.getCommentSonId()));
            return new Result(17, "删除评论成功");

        }else{
            return new Result(-3, "登录失效 请重新登录");
        }

    }



    //根据帖子Id查询帖子下的评论 分页显示评论 并且使帖子的saw加1
    @PostMapping("/selectCommentSonByCommentId")
    public Result selectCommentSonByCommentId(@RequestBody CommentSonVo1 commentSonVo1) {
        //根据commentId查询到评论
        List<CommentSonDto> commentSonDtoList = iCommentSonService.
                selectCommentSonByCommentId(commentSonVo1.getCommentId());
        if (commentSonDtoList.isEmpty()) {
            //将comment表的saw加1
            iCommentSonService.updateCommentSawUp(commentSonVo1.getCommentId());
            return new Result(-10, "暂无评论");
        }else {
            //给每个查询到的帖子的username赋值
            commentSonDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
            //设置头像
            commentSonDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
            //将comment表的saw加1
            iCommentSonService.updateCommentSawUp(commentSonVo1.getCommentId());
            //查询总评论数
            List<Integer> counts=new ArrayList<>();
            counts.add(iCommentSonService.selectCountCommentSonByCommentId(commentSonVo1.getCommentId()));
            Map<String,List> commentSonAndCounts=new LinkedHashMap<>();
            commentSonAndCounts.put("commentSonDtoList", commentSonDtoList);
            commentSonAndCounts.put("counts",counts);

                return new Result(14, "查询评论成功", commentSonAndCounts);

        }
    }


    //发表评论接口
    @PostMapping("/commentSon")
    public Result commentSon(@RequestBody CommentSonVo commentSonVo) {

        //先查询token的值
        String token = iUserService.selectTokenByUserId(commentSonVo.getUserId());

        //判断token
        if (token.equals(commentSonVo.getToken())) {
            //向commentSon插入数据
            iCommentSonService.insterCommentSonByUserIdAndCommentId(commentSonVo.getUserId(),
                    commentSonVo.getCommentId(), commentSonVo.getCommentSonText());
            //向comment表的comments加1
            iCommentSonService.updateCommentSetCommentsByCommentId(commentSonVo.getCommentId());

            return new Result(8, "发布评论成功");
        } else {
            return new Result(-3, "登录失效 请重新登录");
        }
    }


}
