package com.cxl.controller;


import com.cxl.entity.Dto.ArticleDto;
import com.cxl.entity.Po.Article;
import com.cxl.entity.Po.Comment;
import com.cxl.entity.Vo.ArticleVo;
import com.cxl.entity.Vo.CommentDeleteVo;
import com.cxl.hander.GetDetailByUrl;
import com.cxl.service.IArticleService;
import com.cxl.service.IUserService;
import com.cxl.utils.Result;
import com.cxl.utils.WeiXinViolationCheckUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutionException;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-14
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class ArticleController {

    @Resource
    private IArticleService iArticleService;

    @Resource
    private IUserService iUserService;



    //修改文章 有图片版
    @PostMapping("/updateAddArticleAndImage")
    private Result updateAddArticleAndImage(@RequestParam Integer adminUserId,
                                            @RequestParam Integer userId,
                                            @RequestParam Integer articleId,
                                            @RequestParam String articleTitle,
                                            @RequestParam String articleText,
                                            @RequestParam String token,
                              @RequestParam MultipartFile articleAddress
    ) throws IOException {
        //判断token是否失效
        String token1 = iUserService.selectTokenByUserId(adminUserId);

        if (token1.equals(token)) {

            //        String path = "F:/image/" ;//保存到指定的文件目录
            //        String path = "/usr/local/img/" ;//保存到指定的文件目录
            //生成时间
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "thorntree/article/" + userId + "/articleAddress" + df.format(new Date());//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            articleAddress.transferTo(new File(dir.getAbsolutePath() + File.separator + articleAddress.getOriginalFilename()));
            String name = "/" + path2 + "/" + articleAddress.getOriginalFilename();//获取图片的名字

            //修改文章
            iArticleService.updateAddArticleWithOutImage(articleId,articleTitle,articleText,new Date());

            //向articleAddress修改图片地址
            iArticleService.updateArticleAddress(articleId, name);

            return new Result(32, "修改有图片的文章成功");

        }else{
            return new Result(-3, "登录失效 请重新登录");
        }
    }

    //修改文章 无图片版
    @PostMapping("/updateAddArticleWithOutImage")
    private Result updateAddArticleWithOutImage(@RequestParam Integer adminUserId,
                              @RequestParam Integer userId,
                              @RequestParam Integer articleId,
                              @RequestParam String articleTitle,
                              @RequestParam String articleText,
                              @RequestParam String token
    ) throws IOException {
        //判断token是否失效
        String token1 = iUserService.selectTokenByUserId(adminUserId);

        if (token1.equals(token)) {

            //修改文章 无图片版
            iArticleService.updateAddArticleWithOutImage(articleId,articleTitle,articleText,new Date());


            return new Result(31, "修改无图片的文章成功");

        }else{
            return new Result(-3, "登录失效 请重新登录");
        }
    }



    //管理员删除文章
    @PostMapping("/updateArticleStateByUserId")
    public Result updateArticleStateByUserId(@RequestBody ArticleVo articleVo) {
        //判断token是否失效
        String token1 = iUserService.selectTokenByUserId(articleVo.getUserId());

        //判断token的值
        if (token1.equals(articleVo.getToken())) {
            //管理员删除文章
            iArticleService.updateArticleStateByUserId(articleVo.getUserId(), articleVo.getArticleId());

            //删除全部点赞这个文章的点赞
            iArticleService.updateLikesByArticleId(articleVo.getArticleId());
            return new Result(23, "删除文章成功");

        }else{

            return new Result(-3, "登录失效 请重新登录");
        }

    }



    //根据用户点赞查询全部文章信息 分页返回
    @PostMapping("/selectAllLikesArticle")
    public Result selectAllLikesArticle(@RequestParam Integer userId, @RequestParam Integer page) {
        //根据likes查询articleId 分页显示
        List<Integer> likeId = iArticleService.selectUserLikesArticleByPage(userId,page);
        List<ArticleDto> articleDtoList=new ArrayList<>();
        for (int i = 0; i <likeId.size() ; i++) {
            articleDtoList.add(iArticleService.selectArticleByArticleIdByPages(likeId.get(i)));
        }
        //设置用户名
        articleDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
        //设置上传者头像
        articleDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //设置图片地址
        articleDtoList.forEach(i ->i.setArticleAddress(iArticleService.selectArticleAddress(i.getArticleId())));
        //查询该登录账号点赞的帖子
        List<Integer> likes = iArticleService.selectUserLikesArticle(userId);
        //查询全部点赞文章的个数
        List<Integer> counts=new ArrayList<>();
        counts.add(iArticleService.selectUserLikesArticleByUserId(userId));

        Map<String, List> articleByLikes = new LinkedHashMap<>();
        articleByLikes.put("articleDtoList", articleDtoList);
        articleByLikes.put("counts", counts);
        articleByLikes.put("likes", likes);

        if (articleDtoList.size() < 10) {

            return new Result(13, "查询成功已是最后一页", articleByLikes);

        } else {

            return new Result(14, "查询成功 不是最后一页", articleByLikes);

        }

    }



    //根据articleId查询该文章的详细信息 并且实现该文章浏览量加1
    @PostMapping("/selectArticleByArticleId")
    private Result selectArticleByArticleId(@RequestParam Integer articleId, @RequestParam Integer userId) {

        //根据id查询文章的详细信息
        List<ArticleDto> articleDtoList = iArticleService.selectArticleByArticleId(articleId);
        //设置用户名
        articleDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
        //设置上传者头像
        articleDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //设置图片地址
        articleDtoList.forEach(i ->i.setArticleAddress(iArticleService.selectArticleAddress(i.getArticleId())));

        //查询该登录账号点赞的帖子
        List<Integer> likes = iArticleService.selectUserLikesArticle(userId);

        Map<String, List> articleAndLikes = new LinkedHashMap<>();
        articleAndLikes.put("articleDtoList", articleDtoList);
        articleAndLikes.put("likes", likes);
        //根据articleId实现saw加1
        iArticleService.updateArticleSawUp(articleId);

        if (articleDtoList.size() < 10) {

            return new Result(13, "查询成功已是最后一页", articleAndLikes);

        } else {

            return new Result(14, "查询成功 不是最后一页", articleAndLikes);

        }

    }

    //查询全部文章  分页返回
    @PostMapping("/selectAllArticle")
    private Result selectAllArticle(@RequestParam Integer page,@RequestParam Integer userId){
        //查询全部文章 分页返回
        List<ArticleDto> articleDtoList = iArticleService.selectAllArticle(page);
        //设置用户名
        articleDtoList.forEach(i ->i.setUsername(iUserService.selectUsernameByUserId(i.getUserId())));
        //设置上传者头像
        articleDtoList.forEach(i -> i.setUserPortraitAddress(iUserService.selectUserPortraitAddressByUserId(i.getUserId())));
        //设置图片地址
        articleDtoList.forEach(i ->i.setArticleAddress(iArticleService.selectArticleAddress(i.getArticleId())));

        //查询该登录账号点赞的帖子
        List<Integer> likes = iArticleService.selectUserLikesArticle(userId);
        //查询全部文章的个数
        List<Integer> counts=new ArrayList<>();
        counts.add(iArticleService.selectCountArticle());

        Map<String, List> articleAndLikesAndCount = new LinkedHashMap<>();
        articleAndLikesAndCount.put("articleDtoList", articleDtoList);
        articleAndLikesAndCount.put("likes", likes);
        articleAndLikesAndCount.put("counts", counts);

        if (articleDtoList.size() < 10) {

            return new Result(13, "查询成功已是最后一页", articleAndLikesAndCount);

        } else {

            return new Result(14, "查询成功 不是最后一页", articleAndLikesAndCount);

        }


    }

    //上传文章
    @PostMapping("/addArticle")
    private Result addArticle(@RequestParam Integer userId,
                              @RequestParam String articleTitle,
                              @RequestParam String articleText,
                              @RequestParam MultipartFile articleAddress,
                              @RequestParam String token
                              ) throws IOException, ExecutionException, InterruptedException {

        //Map<String,Object>map=securityCheckController.check(articleAddress,articleTitle+articleText);


        //判断token是否失效
        String token1 = iUserService.selectTokenByUserId(userId);

        if (token1.equals(token)) {

            //        String path = "F:/image/" ;//保存到指定的文件目录
            //        String path = "/usr/local/img/" ;//保存到指定的文件目录
            //生成时间
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");

            String path = "/home/image/";//保存到指定的文件目录
            String path2 = "thorntree/article/" + userId + "/articleAddress" + df.format(new Date());//保存到指定的文件目录
            File dir = new File(path + path2);
            if (!dir.exists()) {            //dir.exists() 判断是目录下是否有文件path存在
                dir.mkdirs();               //dir.mkdirs() 如果文件不存在 新建path文件
            }

            articleAddress.transferTo(new File(dir.getAbsolutePath() + File.separator + articleAddress.getOriginalFilename()));
            String name = "/" + path2 + "/" + articleAddress.getOriginalFilename();//获取图片的名字

            //插入article
            Article article=new Article();
            article.setArticleTitle(articleTitle);
            article.setArticleText(articleText);
            article.setUserId(userId);
            article.setArticleTime(new Date());
            article.setLikes("0");
            article.setSaw("0");
            article.setState("0");
            //向article插入数据
            iArticleService.insertArticle(article);
            //向commentAddress插入图片地址
            iArticleService.insertIntoArticleAddress(article.getArticleId(), name);

            return new Result(22, "上传文章成功");

        }else{
            return new Result(-3, "登录失效 请重新登录");
        }
    }


}
