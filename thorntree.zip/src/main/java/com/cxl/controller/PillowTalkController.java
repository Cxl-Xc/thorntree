package com.cxl.controller;


import com.cxl.entity.Po.Likes;
import com.cxl.entity.Po.PillowTalk;
import com.cxl.entity.Vo.PillowTalkVo;
import com.cxl.service.IPillowTalkService;
import com.cxl.service.IUserService;
import com.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-19
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class PillowTalkController {

    @Resource
    private IPillowTalkService iPillowTalkService;

    @Resource
    private IUserService iUserService;


    //发布悄悄话
    @PostMapping("/addPillowTalk")
    public Result addPillowTalk(@RequestBody PillowTalkVo pillowTalkVo) {

        //先去判断token的值
        String token = iUserService.selectTokenByUserId(pillowTalkVo.getUserId());

        if (token.equals(pillowTalkVo.getToken())){
            iPillowTalkService.addPillowTalk(pillowTalkVo);
            return new Result(24, "上传悄悄话成功" );
        }else{
            return new Result(-3, "登录失效 请重新登录");
        }

    }


    //like查询悄悄话
    @PostMapping("/selectPillowTalkByLike")
    public Result selectPillowTalkByLike(@RequestParam String like,@RequestParam Integer page) {

        //根据like  和page查询全部信息
        List<PillowTalk> pillowTalkList = iPillowTalkService.selectPillowTalkByLike(like, page);

        if (pillowTalkList.isEmpty()) {
            return new Result(-14, "查询失败 没有对应的暗号");
        }else{
            //查询全部的暗号留言的数量
            List<Integer> counts = new ArrayList<>();
            counts.add(iPillowTalkService.selectPillowTalkCountByLike(like));

            Map<String, List> pillowTalkLikes = new LinkedHashMap<>();
            pillowTalkLikes.put("pillowTalkList", pillowTalkList);
            pillowTalkLikes.put("counts", counts);

            if (pillowTalkList.size() < 10) {

                return new Result(26, "查询对应暗号 成功已是最后一页", pillowTalkLikes);

            } else {

                return new Result(27, "查询对应暗号成功 不是最后一页", pillowTalkLikes);

            }

        }
    }


}
