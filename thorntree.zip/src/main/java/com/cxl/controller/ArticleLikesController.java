package com.cxl.controller;


import com.cxl.entity.Po.ArticleLikes;
import com.cxl.entity.Po.Likes;
import com.cxl.entity.Vo.ArticleLikesVo;
import com.cxl.entity.Vo.LikesVo;
import com.cxl.service.IArticleLikesService;
import com.cxl.service.IUserService;
import com.cxl.utils.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author itcast
 * @since 2022-06-14
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class ArticleLikesController {

    @Resource
    private IArticleLikesService iArticleLikesService;

    @Resource
    private IUserService iUserService;

    //文章点赞接口
    @PostMapping("/articleLikes")
    public Result articleLikes(@RequestBody ArticleLikesVo articleLikesVo) {

        //先查询token的值
        String token = iUserService.selectTokenByUserId(articleLikesVo.getUserId());

        //判断token的值
        if (token.equals(articleLikesVo.getToken())) {
            //先根据userId和articleId去likes表里查询是否已经点赞
            ArticleLikes articleLikes = iArticleLikesService.selectByUserIdAndArticleId
                    (articleLikesVo.getUserId(), articleLikesVo.getArticleId());

            //根据查询到的值进行判断
            if (articleLikes == null) {
                //空的 向likes表插入数据 并且实现comment表likes加1
                iArticleLikesService.lieksByUserIdAndArticleId(articleLikesVo.getUserId(), articleLikesVo.getArticleId());
                return new Result(9, "点赞成功 之前未点赞",iArticleLikesService.selectLikes(articleLikesVo.getArticleId()));

            } else {
                //有数据  说明已经有记录  判断state的值   如果是0代表点赞了 取消   如果是1代表取消赞 点赞
                if (articleLikes.getState().equals("0")) {
                    //如果是0  则为点赞 取消点赞
                    iArticleLikesService.updateLikesStateDownByArticleId(articleLikes.getUserId(),articleLikes.getArticleId());
                    return new Result(10, "之前点赞过 取消点赞",iArticleLikesService.selectLikes(articleLikesVo.getArticleId()));
                } else {
                    //如果是1  则为取消点赞   点赞
                    iArticleLikesService.updateLikesStateUpByArticleId(articleLikes.getUserId(),articleLikes.getArticleId());
                    return new Result(11,"之前是取消点赞 点赞",iArticleLikesService.selectLikes(articleLikesVo.getArticleId()));
                }
            }
        } else {
            return new Result(-3, "登录失效 请重新登录");
        }
    }




}
