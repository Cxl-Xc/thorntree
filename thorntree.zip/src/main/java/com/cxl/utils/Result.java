package com.cxl.utils;

import lombok.Data;


//返回类
@Data
public class Result {

    private Integer code;
    private String message;
    private Object data;



    public Result(Integer code, String message, Object data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public Result(Integer code, String message) {
        this.code = code;
        this.message = message;

    }

    public Result(Integer code, Object data) {
        this.code = code;
        this.data = data;

    }

    public Result(Integer code) {
        this.code = code;

    }


}
