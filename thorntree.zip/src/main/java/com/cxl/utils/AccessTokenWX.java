package com.cxl.utils;

import java.io.Serializable;

public class AccessTokenWX implements Serializable {
	
	private static final long serialVersionUID = 2336546555320388951L;

	private String errCode;
	private String errMsg;

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	@Override
	public String toString() {
		return "{" +
				"errCode='" + errCode + '\'' +
				", errMsg='" + errMsg + '\'' +
				'}';
	}
}

