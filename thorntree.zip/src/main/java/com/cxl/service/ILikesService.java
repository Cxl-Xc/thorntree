package com.cxl.service;

import com.cxl.entity.Po.Likes;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
public interface ILikesService extends IService<Likes> {

    //根据userId和commentId查询是否有点赞
    Likes selectByUserIdAndCommentId(Integer userId, Integer commentId);

    //向likes表插入数据 并且实现comment的likes+1
    void lieksByUserIdAndCommentId(Integer userId, Integer commentId);

    //取消点赞  并且comment表的likes-1
    void updateLikesStateDownByLikesId(Integer likesId, Integer commentId);

    //修改为点赞 并且实现comment表的likes+1
    void updateLikesStateUpByLikesId(Integer likesId, Integer commentId);

    //根据id查询点赞数
    String selectLikesByCommentId(Integer commentId);
}
