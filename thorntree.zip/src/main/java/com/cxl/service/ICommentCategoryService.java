package com.cxl.service;

import com.cxl.entity.Po.CommentCategory;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
public interface ICommentCategoryService extends IService<CommentCategory> {

    //查询全部的分类
    List<CommentCategory> selectAllCommentCategory();

    //查询人生帖子的数量
    Integer selectCountRenShen();

    //查询事业帖子的数量
    Integer selectCountShiYe();

    //查询爱情帖子的数量
    Integer selectCountAiQing();

    //查询友情的帖子数量
    Integer selectCountYouQing();

    //查询亲情的帖子数量
    Integer selectCountQinQing();
}
