package com.cxl.service;

import com.cxl.entity.Po.UserFeedBack;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2023-03-13
 */
public interface IUserFeedBackService extends IService<UserFeedBack> {

    //用户反馈
    Object insertFeedBackByUserId(UserFeedBack userFeedBack);
}
