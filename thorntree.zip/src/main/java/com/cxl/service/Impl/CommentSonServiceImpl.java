package com.cxl.service.Impl;

import com.cxl.entity.Dto.CommentSonDto;
import com.cxl.entity.Po.CommentSon;
import com.cxl.mapper.CommentSonMapper;
import com.cxl.service.ICommentSonService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Service
public class CommentSonServiceImpl extends ServiceImpl<CommentSonMapper, CommentSon> implements ICommentSonService {

    @Resource
    private CommentSonMapper commentSonMapper;


    @Override
    //向commentSon表插入数据
    public void insterCommentSonByUserIdAndCommentId(Integer userId, Integer commentId, String commentSonText) {


        CommentSon commentSon = new CommentSon();
        commentSon.setUserId(userId);
        commentSon.setCommentId(commentId);
        commentSon.setCommentSonText(commentSonText);
        commentSon.setState("0");
        commentSon.setCommentSonDate(new Date());

        commentSonMapper.insert(commentSon);
    }

    @Override
    //将comment表的comments加1
    public void updateCommentSetCommentsByCommentId(Integer commentId) {
        commentSonMapper.updateCommentSetCommentsByCommentId(commentId);
    }

    @Override
    //根据commentId查询到评论 分页显示
    public List<CommentSonDto> selectCommentSonByCommentId(Integer commentId) {

        return commentSonMapper.selectCommentSonByCommentId(commentId);
    }

    @Override
    //将comment表的saw加1
    public void updateCommentSawUp(Integer commentId) {
        commentSonMapper.updateCommentSawUp(commentId);
    }

    @Override
    //根据commentId查询总评论数
    public Integer selectCountCommentSonByCommentId(Integer commentId) {
        return commentSonMapper.selectCountCommentSonByCommentId(commentId);
    }

    @Override
    //删除评论
    public void updateCommentSonStateByCommentSonId(Integer commentSonId) {
        commentSonMapper.updateCommentSonStateByCommentSonId(commentSonId);
    }

    @Override
    //根据评论Id查询父帖子Id
    public Integer selectCommentIdByCommentSonId(Integer commentSonId) {
        return commentSonMapper.selectCommentIdByCommentSonId(commentSonId);
    }

    @Override
    //将comment表的comments减1
    public void updateCommentSetCommentsDownByCommentId(Integer selectCommentIdByCommentSonId) {
        commentSonMapper.updateCommentSetCommentsDownByCommentId(selectCommentIdByCommentSonId);
    }

    @Override
    //查询下架帖子的评论
    public List<CommentSonDto> selectStateIs2CommentSonByCommentId(Integer commentId) {
        return commentSonMapper.selectStateIs2CommentSonByCommentId(commentId);
    }
}
