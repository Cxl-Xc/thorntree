package com.cxl.service.Impl;

import com.cxl.entity.Po.UserFeedBack;
import com.cxl.mapper.UserFeedBackMapper;
import com.cxl.service.IUserFeedBackService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2023-03-13
 */
@Service
public class UserFeedBackServiceImpl extends ServiceImpl<UserFeedBackMapper, UserFeedBack> implements IUserFeedBackService {

    @Resource
    private UserFeedBackMapper userFeedBackMapper;

    //用户反馈
    @Override
    public Object insertFeedBackByUserId(UserFeedBack userFeedBack) {
        return userFeedBackMapper.insert(userFeedBack);
    }
}
