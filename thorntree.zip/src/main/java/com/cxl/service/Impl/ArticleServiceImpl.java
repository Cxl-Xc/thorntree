package com.cxl.service.Impl;

import com.cxl.entity.Dto.ArticleDto;
import com.cxl.entity.Po.Article;
import com.cxl.mapper.ArticleMapper;
import com.cxl.service.IArticleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-14
 */
@Service
public class ArticleServiceImpl extends ServiceImpl<ArticleMapper, Article> implements IArticleService {

    @Resource
    private ArticleMapper articleMapper;

    @Override
    //向article表插入数据
    public void insertArticle(Article article) {
        articleMapper.insert(article);

    }

    @Override
    //向article表插入数据
    public void insertIntoArticleAddress(Integer articleId, String name) {
        articleMapper.insertIntoArticleAddress(articleId, name);
    }

    @Override
    //查询全部文章 分页显示
    public List<ArticleDto> selectAllArticle(Integer page) {
        Integer page2 = (page - 1) * 10;
        return articleMapper.selectAllArticle(page2);
    }

    @Override
    //根据id查询图片地址
    public String selectArticleAddress(Integer articleId) {
        return articleMapper.selectArticleAddress(articleId);
    }

    @Override
    //查询该登录账号点赞的帖子id
    public List<Integer> selectUserLikesArticle(Integer userId) {
        return articleMapper.selectUserLikesArticle(userId);
    }

    @Override
    //查询全部帖子的数量
    public Integer selectCountArticle() {
        return articleMapper.selectCountArticle();
    }

    @Override
    //根据id查询全部信息
    public List<ArticleDto> selectArticleByArticleId(Integer articleId) {
        return articleMapper.selectArticleByArticleId(articleId);
    }

    @Override
    //根据articleId实现saw加1
    public void updateArticleSawUp(Integer articleId) {
        articleMapper.updateArticleSawUp(articleId);
    }

    @Override
    //根据likes查询全部信息 分页显示
    public List<Integer> selectUserLikesArticleByPage(Integer userId, Integer page) {
        Integer page2 = (page - 1) * 10;
        return articleMapper.selectUserLikesArticleByPage(page2,userId);
    }

    @Override
    //根据articleId查询文章
    public ArticleDto selectArticleByArticleIdByPages(Integer articleId) {
        return articleMapper.selectArticleByArticleIdByPages(articleId);
    }

    @Override
    //查询全部点赞的文章个数
    public Integer selectUserLikesArticleByUserId(Integer userId) {
        return articleMapper.selectUserLikesArticleByUserId(userId);
    }

    @Override
    //管理员删除文章
    public void updateArticleStateByUserId(Integer userId, Integer articleId) {
        articleMapper.updateArticleStateByUserId(userId, articleId);
    }

    @Override
    //删除全部点赞这个文章的点赞
    public void updateLikesByArticleId(Integer articleId) {
        articleMapper.updateLikesByArticleId(articleId);
    }

    @Override
    //更新文章
    public void updateAddArticleWithOutImage(Integer articleId, String articleTitle, String articleText, Date date) {
        articleMapper.updateAddArticleWithOutImage(articleId, articleTitle, articleText, date);

    }

    @Override
    //修改文章图片地址
    public void updateArticleAddress(Integer articleId, String name) {
        articleMapper.updateArticleAddress(articleId, name);
    }
}
