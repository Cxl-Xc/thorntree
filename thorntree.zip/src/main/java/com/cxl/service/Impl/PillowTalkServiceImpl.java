package com.cxl.service.Impl;

import com.cxl.entity.Po.PillowTalk;
import com.cxl.entity.Vo.PillowTalkVo;
import com.cxl.mapper.PillowTalkMapper;
import com.cxl.service.IPillowTalkService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-19
 */
@Service
public class PillowTalkServiceImpl extends ServiceImpl<PillowTalkMapper, PillowTalk> implements IPillowTalkService {


    @Resource
    private PillowTalkMapper pillowTalkMapper;

    //上传悄悄话
    @Override
    public void addPillowTalk(PillowTalkVo pillowTalkVo) {

        PillowTalk pillowTalk = new PillowTalk();
        pillowTalk.setPillowTalkKey(pillowTalkVo.getPillowTalkKey());
        pillowTalk.setPillowTalkText(pillowTalkVo.getPillowTalkText());
        pillowTalk.setUserId(pillowTalkVo.getUserId());
        pillowTalk.setState("0");
        pillowTalk.setTime(new Date());

        pillowTalkMapper.insert(pillowTalk);
    }

    @Override
    //根据like和page查询全部信息
    public List<PillowTalk> selectPillowTalkByLike(String like, Integer page) {
        Integer page2 = (page - 1) * 10;
        return pillowTalkMapper.selectPillowTalkByLike(like,page2);
    }

    @Override
    //查询全部like帖子数量
    public Integer selectPillowTalkCountByLike(String like) {
        return pillowTalkMapper.selectPillowTalkCountByLike(like);
    }
}
