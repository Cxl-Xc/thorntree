package com.cxl.service.Impl;

import com.cxl.entity.Po.CommentCategory;
import com.cxl.mapper.CommentCategoryMapper;
import com.cxl.service.ICommentCategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Service
public class CommentCategoryServiceImpl extends ServiceImpl<CommentCategoryMapper, CommentCategory> implements ICommentCategoryService {


    @Resource
    private CommentCategoryMapper commentCategoryMapper;

    @Override
    //查询全部的分类
    public List<CommentCategory> selectAllCommentCategory() {
        return commentCategoryMapper.selectAllCommentCategory();
    }

    @Override
    //查询人生帖子的数量
    public Integer selectCountRenShen() {
        return commentCategoryMapper.selectCountRenShen();
    }

    @Override
    //查询事业帖子的数量
    public Integer selectCountShiYe() {
        return commentCategoryMapper.selectCountShiYe();
    }

    @Override
    //查询爱情帖子的数量
    public Integer selectCountAiQing() {
        return commentCategoryMapper.selectCountAiQing();
    }

    @Override
    //查询友情帖子的数量
    public Integer selectCountYouQing() {
        return commentCategoryMapper.selectCountYouQing();
    }

    @Override
    //查询亲情的帖子的数量
    public Integer selectCountQinQing() {
        return commentCategoryMapper.selectCountQinQing();
    }
}
