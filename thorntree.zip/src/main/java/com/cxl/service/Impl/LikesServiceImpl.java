package com.cxl.service.Impl;

import com.cxl.entity.Po.Likes;
import com.cxl.mapper.LikesMapper;
import com.cxl.service.ILikesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Service
public class LikesServiceImpl extends ServiceImpl<LikesMapper, Likes> implements ILikesService {

    @Resource
    private LikesMapper likesMapper;


    @Override
    //根据userId和commentId查询是否有点赞
    public Likes selectByUserIdAndCommentId(Integer userId, Integer commentId) {
        return likesMapper.selectByUserIdAndCommentId(userId, commentId);
    }

    @Override
    //向likes表插入数据 并实现 comment表的likes加1
    public void lieksByUserIdAndCommentId(Integer userId, Integer commentId) {
        //点赞
        likesMapper.lieksByUserIdAndCommentId(userId, commentId, new Date());
        //likes+1
        likesMapper.updateCommentLikesUpByCommentId(commentId);
    }

    @Override
    //取消点赞 并且comment表的likes-1
    public void updateLikesStateDownByLikesId(Integer likesId,Integer commentId) {
        //取消点赞
        likesMapper.updateLikesStateDownByLikesId(likesId);
        //likes-1
        likesMapper.updateCommentLikesDownByCommentId(commentId);

    }

    @Override
    //修改为点赞 并且实现comment表的likes+1
    public void updateLikesStateUpByLikesId(Integer likesId, Integer commentId) {
        //修改为点赞
        likesMapper.updateLikesStateUpByLikesId(likesId,new Date());
        //修改comment的likes+1
        likesMapper.updateCommentLikesUpByCommentId(commentId);
    }

    @Override
    //根据id查询点赞数
    public String selectLikesByCommentId(Integer commentId) {
        return likesMapper.selectLikesByCommentId(commentId);
    }
}
