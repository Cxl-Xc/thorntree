package com.cxl.service.Impl;

import com.cxl.entity.Po.User;
import com.cxl.entity.Po.UserPortraitAddress;
import com.cxl.mapper.UserPortraitAddressMapper;
import com.cxl.service.IUserPortraitAddressService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Service
public class UserPortraitAddressServiceImpl extends ServiceImpl<UserPortraitAddressMapper, UserPortraitAddress> implements IUserPortraitAddressService {

    @Resource
    private UserPortraitAddressMapper userPortraitAddressMapper;

    @Override
    //根据userId查询是否有这个用户
    public User selectByUserId(Integer userId) {
        return userPortraitAddressMapper.selectByUserId(userId);
    }

    @Override
    //插入用户头像
    public void updatePortraitAddress(Integer userId, String name) {
        userPortraitAddressMapper.updatePortraitAddress(userId, name);
    }
}
