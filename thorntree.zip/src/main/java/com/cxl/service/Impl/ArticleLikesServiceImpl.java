package com.cxl.service.Impl;

import com.cxl.entity.Po.ArticleLikes;
import com.cxl.mapper.ArticleLikesMapper;
import com.cxl.service.IArticleLikesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-14
 */
@Service
public class ArticleLikesServiceImpl extends ServiceImpl<ArticleLikesMapper, ArticleLikes> implements IArticleLikesService {

    @Resource
    private ArticleLikesMapper articleLikesMapper;


    @Override
    //先根据userId和articleId去likes表里查询是否已经点赞
    public ArticleLikes selectByUserIdAndArticleId(Integer userId, Integer articleId) {
        return articleLikesMapper.selectByUserIdAndArticleId(userId, articleId);
    }

    @Override
    //根据userId和ArticleId向ArticleLikes表插入数据 并使Article表的likes加1
    public void lieksByUserIdAndArticleId(Integer userId, Integer articleId) {
        //根据userId和ArticleId向ArticleLikes表插入数据
        ArticleLikes articleLikes = new ArticleLikes();
        articleLikes.setArticleId(articleId);
        articleLikes.setLastLikeTime(new Date());
        articleLikes.setUserId(userId);
        articleLikes.setState("0");
        articleLikesMapper.insert(articleLikes);

        //使Article表的likes加1
        articleLikesMapper.updateArticleLikesUp(articleId);

    }

    @Override
    //取消点赞
    public void updateLikesStateDownByArticleId(Integer userId, Integer articleId) {
        //取消点赞
        articleLikesMapper.updateLikesStateDownByArticleId(userId, articleId);
        //使Article表的likes减去1
        articleLikesMapper.updateArticleLikesDown(articleId);
    }

    @Override
    //点赞
    public void updateLikesStateUpByArticleId(Integer userId, Integer articleId) {
        //点赞
        articleLikesMapper.updateLikesStateUpByArticleId(userId, articleId, new Date());
        //使Article表的likes加1
        articleLikesMapper.updateArticleLikesUp(articleId);

    }

    @Override
    //根据Id查询likes
    public Integer selectLikes(Integer articleId) {
        return articleLikesMapper.selectLikes(articleId);
    }
}
