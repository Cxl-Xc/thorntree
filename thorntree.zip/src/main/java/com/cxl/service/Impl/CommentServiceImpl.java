package com.cxl.service.Impl;

import com.cxl.entity.Dto.CommentDot1;
import com.cxl.entity.Dto.CommentDto;
import com.cxl.entity.Po.Comment;
import com.cxl.entity.Po.CommentAddress;
import com.cxl.mapper.CommentMapper;
import com.cxl.service.ICommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements ICommentService {

    @Resource
    private CommentMapper commentMapper;

    @Override
    //根据类别名字查询是否有这个类别 返回类别id
    public Integer selectCommentCategoryIdByCommentCategoryName(String commentCategoryName) {
        return commentMapper.selectCommentCategoryIdByCommentCategoryName(commentCategoryName);
    }

    @Override
    //向comment插入数据
    public void insertIntoComment(Comment comment) {
        commentMapper.insert(comment);
    }

    @Override
    //向commentAddress表插入数据
    public void insertIntoCommentAddress(Integer commentId, String name) {
        commentMapper.insertIntoCommentAddress(commentId, name);
    }

    @Override
    //查询全部帖子分页显示
    public List<CommentDto> selectAllCommentByPage(Integer page) {
        Integer page2 = (page - 1) * 10;
        return commentMapper.selectAllCommentByPage(page2);
    }

    @Override
    //根据帖子Id查询commentAddress
    public List<CommentAddress> selectCommentAddress(Integer commentId) {
        return commentMapper.selectCommentAddress(commentId);
    }

    @Override
    //根据commentCategoryId查询commentCategoryName
    public String selectCommentCategoryNameBycommentCategoryId(Integer commentCategoryId) {
        return commentMapper.selectCommentCategoryNameBycommentCategoryId(commentCategoryId);
    }

    @Override
    //查询该用户点赞的所有帖子的id
    public List<Integer> selectUserLikeCommentId(Integer userId) {
        return commentMapper.selectUserLikeCommentId(userId);
    }

    @Override
    //查询全部帖子的数量
    public Integer selectCountComment() {
        return commentMapper.selectCountComment();
    }

    @Override
    //根据类别查询帖子 分页显示
    public List<CommentDto> selectCommentByCommentCategoryIdAndPage(Integer page, Integer commentCategoryId) {
        Integer page2 = (page - 1) * 10;
        return commentMapper.selectCommentByCommentCategoryIdAndPage(page2,commentCategoryId);
    }

    @Override
    //查询全部类别帖子的数量
    public Integer selectCountCommentByCommentCategoryId(Integer commentCategoryId) {
        return commentMapper.selectCountCommentByCommentCategoryId(commentCategoryId);
    }

    @Override
    //根据commentTitle查询全部帖子 分页显示
    public List<CommentDto> selectCommentByLikeTitleAndPage(String commentTitle, Integer page) {
        Integer page2 = (page - 1) * 10;
        return commentMapper.selectCommentByLikeTitleAndPage(commentTitle,page2);
    }

    @Override
    //根据commentTitle查询到所有帖子的数量
    public Integer selectCountCommentByLikeCommentTitle(String commentTitle) {
        return commentMapper.selectCountCommentByLikeCommentTitle(commentTitle);
    }

    @Override
    //根据userId查询该用户发布的帖子 分页显示
    public List<CommentDto> selectCommentByUserIdAndPage(Integer userId, Integer page) {
        Integer page2 = (page - 1) * 10;
        return commentMapper.selectCommentByUserIdAndPage(userId, page2);
    }

    @Override
    //根据userId查询全部帖子的数量
    public Integer selectCountCommentByUserId(Integer userId) {
        return commentMapper.selectCountCommentByUserId(userId);
    }

    @Override
    //根据userId去like表查询用户喜欢的帖子的Id
    public List<Integer> selectLikeCommentByUserId(Integer userId,Integer page) {
        Integer page2 = (page - 1) * 10;
        return commentMapper.selectLikeCommentByUserId(userId,page2);
    }

    @Override
    //根据commentId查询comment
    public CommentDto selectCommentByCommentIdForLikes(Integer commentId) {
        return commentMapper.selectCommentByCommentIdForLikes(commentId);
    }

    @Override
    //根据userId查询全部喜欢的帖子的数量
    public Integer selectCountCommentByUserIdLike(Integer userId) {
        return commentMapper.selectCountCommentByUserIdLike(userId);
    }

    @Override
    //用户自己删除帖子
    public void updateCommentStateByUserId(Integer userId, Integer commentId) {
        commentMapper.updateCommentStateByUserId(userId, commentId);
    }

    @Override
    //删除帖子评论
    public void updateCommentSonStateByCommentId(Integer commentId) {
        commentMapper.updateCommentSonStateByCommentId(commentId);
    }

    @Override
    //删除喜欢这个帖子的所有喜欢
    public void updateLikesByCommentId(Integer commentId) {
        commentMapper.updateLikesByCommentId(commentId);
    }

    @Override
    //根据commentId查询comment
    public List<CommentDto> selectCommentByCommentId(Integer commentId) {
        return commentMapper.selectCommentByCommentId(commentId);
    }

    @Override
    //修改帖子的state为2
    public void updateCommentStateByTo2(Integer commentId) {
        commentMapper.updateCommentStateByTo2(commentId);

    }

    @Override
    //修改likes表下的state为1
    public void updateLikesStateByCommentId(Integer commentId) {
        commentMapper.updateLikesStateByCommentId(commentId);
    }


    @Override
    //修改帖子的state为0
    public void updateCommentStateByTo0(Integer commentId) {
        commentMapper.updateCommentStateByTo0(commentId);
    }

    @Override
    //查询全部下架帖子的数量
    public Integer selectCounts() {
        return commentMapper.selectCounts();
    }

    @Override
    //根据帖子Id查询评论数  浏览量  点赞数量
    public CommentDot1 selectLikesAndCommentsAndSawByCommentId(Integer commentId) {
        return commentMapper.selectLikesAndCommentsAndSawByCommentId(commentId);
    }

    @Override
    //根据id查询下架帖子
    public List<CommentDto> selectCommentByCommentIdAndStateIs2(Integer commentId) {
        return commentMapper.selectCommentByCommentIdAndStateIs2(commentId);
    }
}
