package com.cxl.service.Impl;

import com.cxl.entity.Dto.CommentDto;
import com.cxl.entity.Dto.UserDto;
import com.cxl.entity.Po.User;
import com.cxl.mapper.UserMapper;
import com.cxl.service.IUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2022-06-12
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

    @Resource
    private UserMapper userMapper;


    @Override
    //根据username查询是否已经注册账号
    public User selectUserByUsername(String username) {
        return userMapper.selectUserByUsername(username);
    }

    @Override
    //账号注册
    public Integer register(User user) {
        User userPo = new User();
        userPo.setUsername(user.getUsername());
        String md5Password = DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
        userPo.setPassword(md5Password);
        userPo.setState("0");
        userPo.setEmail("未认证邮箱");
        userPo.setToken("未登录");
        userMapper.insert(userPo);
        return userPo.getUserId();
    }

    @Override
    //上传默认头像
    public void insertDefaultUserPortraitAddress(Integer userId) {
        String defaultUserPortraitAddress = "/thorntree/userAddress/userDefaultAddress/默认头像.jpg";

        //插入用户头像
        userMapper.insertDefaultUserPortraitAddress(userId, defaultUserPortraitAddress);


    }

    @Override
    //插入用户权限
    public void insertDefaultUserRole(Integer userId) {
        String role = "user";
        //插入用户权限
        userMapper.insertDefaultUserRole(userId,role);
    }

    @Override
    //根据账号密码查询账号是否存在
    public User selectUserByUsernameAndPassword(String username, String password) {
        String passwordPo=DigestUtils.md5DigestAsHex(password.getBytes());
        //查询账号是否已经存在
        return userMapper.selectUserByUsernameAndPassword(username,passwordPo);
    }

    @Override
    //根据userId插入token
    public void updateUserToken(Integer userId, String token) {
        userMapper.updateUserToken(userId, token);
    }

    @Override
    //获取头像
    public String selectUserPortraitAddressByUserId(Integer userId) {
        return userMapper.selectUserPortraitAddressByUserId(userId);
    }

    @Override
    //获取用户权限
    public String selectUserRoleByUserId(Integer userId) {
        return userMapper.selectUserRoleByUserId(userId);
    }

    @Override
    //获取token的值
    public String selectTokenByUserId(Integer userId) {
        return userMapper.selectTokenByUserId(userId);
    }

    @Override
    //删除用户
    public Integer updateUserState(Integer updateUserId) {
        return userMapper.updateUserState(updateUserId);
    }

    @Override
    //删除用户权限
    public void deleteUserRole(Integer updateUserId) {
        userMapper.deleteUserRole(updateUserId);
    }

    @Override
    //插入邮箱
    public void updateUserEmailByUserId(Integer userId, String email) {
        userMapper.updateUserEmailByUserId(userId, email);
    }

    @Override
    //修改密码
    public void updateUserPassword(Integer userId, String newPassword) {
        String newMd5Password = DigestUtils.md5DigestAsHex(newPassword.getBytes());
        userMapper.updateUserPassword(userId, newMd5Password);
    }

    @Override
    //根据邮箱查询账号
    public User selectUserByEmail(String email) {
        return userMapper.selectUserByEmail(email);
    }

    @Override
    //根据userId查询username
    public String selectUsernameByUserId(Integer userId) {
        return userMapper.selectUsernameByUserId(userId);
    }

    @Override
    //修改用户名
    public void changeUserName(Integer userId, String newUsername) {
        userMapper.changeUserName(userId, newUsername);
    }

    @Override
    //查询用户权限为user的id
    public List<Integer> selectAllRoleByUser(Integer page) {
        Integer page2 = (page - 1) * 10;
        return userMapper.selectAllRoleByUser(page2);
    }

    @Override
    //根据userId查询全部User
    public UserDto selectUserByUserId(Integer userId) {
        return userMapper.selectUserByUserId(userId);
    }

    @Override
    //查询全部用户的数量
    public Integer selectCountByUser() {
        return userMapper.selectCountByUser();
    }

    @Override
    //查询全部下架帖子分页显示
    public List<CommentDto> selectCommentByStateIs2(Integer page) {
        Integer page2 = (page - 1) * 10;
        return userMapper.selectCommentByStateIs2(page2);
    }


    @Override
    //根据openId查询数据库是否有此账号 返回userId
    public User selectUserByOpenId(String openId) {
        User user = userMapper.selectUserIdByOpenId(openId);
        return user;
    }

    @Override
    //根据openID插入账号
    public Integer registerByOpenId(User user2) {
        User userPo=new User();
        userPo.setUsername(user2.getUsername());
        userPo.setPassword("******");
        userPo.setState("0");
        userPo.setToken(user2.getToken());
        userPo.setEmail("未认证邮箱");
        userPo.setOpenId(user2.getOpenId());
        userMapper.insert(userPo);
        //根据openId查询USerID
        return userMapper.selectUserIdByOpenId(user2.getOpenId()).getUserId();
    }

}
