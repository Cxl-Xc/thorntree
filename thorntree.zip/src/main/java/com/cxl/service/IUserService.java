package com.cxl.service;

import com.cxl.entity.Dto.CommentDto;
import com.cxl.entity.Dto.UserDto;
import com.cxl.entity.Po.User;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-12
 */
public interface IUserService extends IService<User> {

    //根据username查询是否已经注册账号
    User selectUserByUsername(String username);

    //账号注册
    Integer register(User user);

    //上传默认头像
    void insertDefaultUserPortraitAddress(Integer userId);

    //插入用户权限
    void insertDefaultUserRole(Integer userId);

    //根据账号密码查询账号是否存在
    User selectUserByUsernameAndPassword(String username, String password);

    //根据userId插入token
    void updateUserToken(Integer userId, String token);

    //获取头像
    String selectUserPortraitAddressByUserId(Integer userId);

    //获取权限
    String selectUserRoleByUserId(Integer userId);

    //获取token的值
    String selectTokenByUserId(Integer userId);

    //删除用户
    Integer updateUserState(Integer updateUserId);

    //删除用户权限
    void deleteUserRole(Integer updateUserId);

    //插入邮箱
    void updateUserEmailByUserId(Integer userId, String email);

    //修改密码
    void updateUserPassword(Integer userId, String newPassword);

    //根据邮箱查询账号
    User selectUserByEmail(String email);

    //根据userId查询username
    String selectUsernameByUserId(Integer userId);

    //修改用户名
    void changeUserName(Integer userId, String newUsername);

    //查询全部权限为user的用户Id
    List<Integer> selectAllRoleByUser(Integer page);

    //根据id查询全部用户信息
    UserDto selectUserByUserId(Integer userId);

    //查询全部用户的数量
    Integer selectCountByUser();

    //查询全部下架帖子 分页显示
    List<CommentDto> selectCommentByStateIs2(Integer page);

    //根据code获取的openId去数据库查询是否有这个账号
    User selectUserByOpenId(String openId);

    //根据OpenID插入账号
    Integer registerByOpenId(User user2);
}
