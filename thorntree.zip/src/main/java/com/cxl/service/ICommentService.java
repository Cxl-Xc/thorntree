package com.cxl.service;

import com.cxl.entity.Dto.CommentDot1;
import com.cxl.entity.Dto.CommentDto;
import com.cxl.entity.Po.Comment;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cxl.entity.Po.CommentAddress;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
public interface ICommentService extends IService<Comment> {

    //根据类别名称查询是否有这个类别 返回类别id
    Integer selectCommentCategoryIdByCommentCategoryName(String commentCategoryName);

    //向comment插入数据
    void insertIntoComment(Comment comment);

    //向commentAddress表插入数据
    void insertIntoCommentAddress(Integer commentId, String name);

    //查询全部帖子 分页显示
    List<CommentDto> selectAllCommentByPage(Integer page);

    //根据帖子id查询commentAddress
    List<CommentAddress> selectCommentAddress(Integer commentId);

    //根据commentCategoryId查询commentCategoryName
    String selectCommentCategoryNameBycommentCategoryId(Integer commentCategoryId);

    //查询该用户点赞的帖子id
    List<Integer> selectUserLikeCommentId(Integer userId);

    //查询全部帖子的数量
    Integer selectCountComment();

    //根据类别查询帖子 分页显示
    List<CommentDto> selectCommentByCommentCategoryIdAndPage(Integer page, Integer commentCategoryId);

    //查询全部类别帖子的数量
    Integer selectCountCommentByCommentCategoryId(Integer commentCategoryId);

    //根据commentTitle查询全部帖子 分页显示
    List<CommentDto> selectCommentByLikeTitleAndPage(String commentTitle, Integer page);

    //根据commentTitle查询到全部帖子的数量
    Integer selectCountCommentByLikeCommentTitle(String commentTitle);

    //根据userId查询该用户发布的帖子 分页显示
    List<CommentDto> selectCommentByUserIdAndPage(Integer userId, Integer page);

    //根据userId查询全部帖子的数量
    Integer selectCountCommentByUserId(Integer userId);

    //根据userId去like表查询用户喜欢的帖子的Id 分页显示
    List<Integer> selectLikeCommentByUserId(Integer userId,Integer page);

    //根据查询到的commentId去comment表查询数据
    CommentDto selectCommentByCommentIdForLikes(Integer commentId);

    //根据userid查询全部喜欢的帖子的数量
    Integer selectCountCommentByUserIdLike(Integer userId);

    //用户自己删除的帖子
    void updateCommentStateByUserId(Integer userId, Integer commentId);

    //删除帖子下面的评论
    void updateCommentSonStateByCommentId(Integer commentId);

    //删除这个帖子下面的全部点赞信息
    void updateLikesByCommentId(Integer commentId);

    //根据帖子Id查询帖子
    List<CommentDto> selectCommentByCommentId(Integer commentId);

    //修改帖子的state为2
    void updateCommentStateByTo2(Integer commentId);

    //修改likes表下的state为1
    void updateLikesStateByCommentId(Integer commentId);

    //修改帖子的state为0
    void updateCommentStateByTo0(Integer commentId);

    //查询全部下架帖子的数量
    Integer selectCounts();

    //根据帖子id查询帖子评论数量 点赞数量 浏览量
    CommentDot1 selectLikesAndCommentsAndSawByCommentId(Integer commentId);

    //根据id查询下架的帖子
    List<CommentDto> selectCommentByCommentIdAndStateIs2(Integer commentId);
}
