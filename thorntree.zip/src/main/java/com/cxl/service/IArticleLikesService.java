package com.cxl.service;

import com.cxl.entity.Po.ArticleLikes;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-14
 */
public interface IArticleLikesService extends IService<ArticleLikes> {

    //先根据userId和articleId去likes表里查询是否已经点赞
    ArticleLikes selectByUserIdAndArticleId(Integer userId, Integer articleId);

    //根据userId和ArticleId向ArticleLikes表插入数据 并使Article表的likes加1
    void lieksByUserIdAndArticleId(Integer userId, Integer articleId);

    //取消点赞
    void updateLikesStateDownByArticleId(Integer userId, Integer articleId);

    //点赞
    void updateLikesStateUpByArticleId(Integer userId, Integer articleId);

    //根据id查询likes
    Integer selectLikes(Integer articleId);
}
