package com.cxl.service;

import com.cxl.entity.Po.User;
import com.cxl.entity.Po.UserPortraitAddress;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
public interface IUserPortraitAddressService extends IService<UserPortraitAddress> {

    //根据userId查询是否有这个用户
    User selectByUserId(Integer userId);

    //插入用户头像
    void updatePortraitAddress(Integer userId, String name);
}
