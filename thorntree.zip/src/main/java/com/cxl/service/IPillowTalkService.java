package com.cxl.service;

import com.cxl.entity.Po.PillowTalk;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cxl.entity.Vo.PillowTalkVo;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-19
 */
public interface IPillowTalkService extends IService<PillowTalk> {

    //上传悄悄话
    void addPillowTalk(PillowTalkVo pillowTalkVo);

    //根据like  和  page查询全部信息
    List<PillowTalk> selectPillowTalkByLike(String like, Integer page);

    //查询全部like帖子数量
    Integer selectPillowTalkCountByLike(String like);
}
