package com.cxl.service;

import com.cxl.entity.Dto.ArticleDto;
import com.cxl.entity.Po.Article;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Date;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-14
 */
public interface IArticleService extends IService<Article> {

    //向article表插入数据
    void insertArticle(Article article);

    //向articleAddress表插入数据
    void insertIntoArticleAddress(Integer articleId, String name);

    //查询全部文章 分页显示
    List<ArticleDto> selectAllArticle(Integer page);

    //根据id查询图片地址
    String selectArticleAddress(Integer articleId);

    //查询该登录账号点赞的帖子
    List<Integer> selectUserLikesArticle(Integer userId);

    //查询全部帖子的数量
    Integer selectCountArticle();

    //根据id查询全部信息
    List<ArticleDto> selectArticleByArticleId(Integer articleId);

    //根据articleId实现saw加1
    void updateArticleSawUp(Integer articleId);

    //根据likes查询全部信息 分页显示
    List<Integer> selectUserLikesArticleByPage(Integer userId, Integer page);

    //根据articleId查询文章
    ArticleDto selectArticleByArticleIdByPages(Integer articleId);

    //查询全部点赞的文章个数
    Integer selectUserLikesArticleByUserId(Integer userId);

    //管理员删除文章
    void updateArticleStateByUserId(Integer userId, Integer articleId);

    //删除全都点赞这个文章的点赞
    void updateLikesByArticleId(Integer articleId);

    //更新文章
    void updateAddArticleWithOutImage(Integer articleId, String articleTitle, String articleText, Date date);

    //修改文章图片地址
    void updateArticleAddress(Integer articleId, String name);
}
