package com.cxl.service;

import com.cxl.entity.Dto.CommentSonDto;
import com.cxl.entity.Po.CommentSon;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
public interface ICommentSonService extends IService<CommentSon> {

    //向commentSon表插入数据
    void insterCommentSonByUserIdAndCommentId(Integer userId, Integer commentId, String commentSonText);

    //向comment表的comments的值加1
    void updateCommentSetCommentsByCommentId(Integer commentId);

    //根据commentId查询到评论 分页显示
    List<CommentSonDto> selectCommentSonByCommentId(Integer commentId);

    //将comment表的saw加1
    void updateCommentSawUp(Integer commentId);

    //更具commentId查询总评论数
    Integer selectCountCommentSonByCommentId(Integer commentId);

    //删除评论
    void updateCommentSonStateByCommentSonId(Integer commentSonId);

    //根据评论Id查询父帖子Id
    Integer selectCommentIdByCommentSonId(Integer commentSonId);

    //将comment表的comments减1
    void updateCommentSetCommentsDownByCommentId(Integer selectCommentIdByCommentSonId);

    //查询下架帖子的评论
    List<CommentSonDto> selectStateIs2CommentSonByCommentId(Integer commentId);
}
