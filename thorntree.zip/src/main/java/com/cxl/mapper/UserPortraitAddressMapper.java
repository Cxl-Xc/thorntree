package com.cxl.mapper;

import com.cxl.entity.Po.User;
import com.cxl.entity.Po.UserPortraitAddress;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
public interface UserPortraitAddressMapper extends BaseMapper<UserPortraitAddress> {

    //根据userId查询是否有这个用户
    User selectByUserId(Integer userId);

    //根据userId和路径插入头像地址
    void updatePortraitAddress(Integer userId, String name);
}
