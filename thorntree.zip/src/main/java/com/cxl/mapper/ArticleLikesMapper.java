package com.cxl.mapper;

import com.cxl.entity.Po.ArticleLikes;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Date;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-14
 */
public interface ArticleLikesMapper extends BaseMapper<ArticleLikes> {

    //先根据userId和articleId去likes表里查询是否已经点赞
    ArticleLikes selectByUserIdAndArticleId(Integer userId, Integer articleId);

    //使article表的likes加1
    void updateArticleLikesUp(Integer articleId);

    //取消点赞
    void updateLikesStateDownByArticleId(Integer userId, Integer articleId);

    //使Article表的likes减去1
    void updateArticleLikesDown(Integer articleId);

    //点赞
    void updateLikesStateUpByArticleId(Integer userId, Integer articleId, Date date);

    //根据id查询likes
    Integer selectLikes(Integer articleId);
}
