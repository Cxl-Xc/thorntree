package com.cxl.mapper;

import com.cxl.entity.Dto.CommentDto;
import com.cxl.entity.Dto.UserDto;
import com.cxl.entity.Po.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-12
 */
public interface UserMapper extends BaseMapper<User> {

    //根据username查询是否已经有账号
    User selectUserByUsername(String username);
    //插入用户头像
    void insertDefaultUserPortraitAddress(Integer userId, String defaultUserPortraitAddress);
    //插入用户权限
    void insertDefaultUserRole(Integer userId, String role);
    //查询账号是否已经存在
    User selectUserByUsernameAndPassword(String username, String passwordPo);
    //根据userId插入token
    void updateUserToken(Integer userId, String token);
    //获取头像
    String selectUserPortraitAddressByUserId(Integer userId);
    //获取用户权限
    String selectUserRoleByUserId(Integer userId);
    //获取token
    String selectTokenByUserId(Integer userId);
    //删除用户
    Integer updateUserState(Integer updateUserId);
    //删除用户权限
    void deleteUserRole(Integer updateUserId);
    //插入邮箱
    void updateUserEmailByUserId(Integer userId, String email);
    //修改密码
    void updateUserPassword(Integer userId, String newMd5Password);
    //根据邮箱查询账号
    User selectUserByEmail(String email);
    //根据userId查询username
    String selectUsernameByUserId(Integer userId);
    //修改用户名
    void changeUserName(Integer userId, String newUsername);
    //查询用户权限为user的id
    List<Integer> selectAllRoleByUser(Integer page2);
    //根据userId查询全部user
    UserDto selectUserByUserId(Integer userId);
    //查询全部用户的数量
    Integer selectCountByUser();
    //查询全部下架帖子 分页显示
    List<CommentDto> selectCommentByStateIs2(Integer page2);

    //根据openId查询userId
    User selectUserIdByOpenId(String openId);


}
