package com.cxl.mapper;

import com.cxl.entity.Dto.CommentSonDto;
import com.cxl.entity.Po.CommentSon;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
public interface CommentSonMapper extends BaseMapper<CommentSon> {

    //将comment的comments的值加1
    void updateCommentSetCommentsByCommentId(Integer commentId);

    //根据commentId查询到评论 分页显示
    List<CommentSonDto> selectCommentSonByCommentId(Integer commentId);

    //将comment表的saw加1
    void updateCommentSawUp(Integer commentId);

    //根据commentId查询总评论数
    Integer selectCountCommentSonByCommentId(Integer commentId);

    //删除评论
    void updateCommentSonStateByCommentSonId(Integer commentSonId);

    //根据评论Id查询父帖子Id
    Integer selectCommentIdByCommentSonId(Integer commentSonId);

    //将comment表的comments减1
    void updateCommentSetCommentsDownByCommentId(Integer selectCommentIdByCommentSonId);

    //查询下架帖子的评论
    List<CommentSonDto> selectStateIs2CommentSonByCommentId(Integer commentId);
}
