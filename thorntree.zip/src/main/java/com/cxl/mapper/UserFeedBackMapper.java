package com.cxl.mapper;

import com.cxl.entity.Po.UserFeedBack;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2023-03-13
 */
public interface UserFeedBackMapper extends BaseMapper<UserFeedBack> {

}
