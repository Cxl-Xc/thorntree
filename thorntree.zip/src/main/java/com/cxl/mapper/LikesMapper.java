package com.cxl.mapper;

import com.cxl.entity.Po.Likes;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Date;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
public interface LikesMapper extends BaseMapper<Likes> {
    //根据userId和commentId查询是否有点赞
    Likes selectByUserIdAndCommentId(Integer userId, Integer commentId);

    //向likes表插入数据
    void lieksByUserIdAndCommentId(Integer userId, Integer commentId, Date date);

    //实现comment表的likes+1
    void updateCommentLikesUpByCommentId(Integer commentId);

    //取消点赞
    void updateLikesStateDownByLikesId(Integer likesId);

    //comment表like-1
    void updateCommentLikesDownByCommentId(Integer commentId);

    //修改为点赞
    void updateLikesStateUpByLikesId(Integer likesId, Date date);

    //根据id查询点赞数
    String selectLikesByCommentId(Integer commentId);
}
