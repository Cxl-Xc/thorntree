package com.cxl.mapper;

import com.cxl.entity.Po.CommentCategory;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
public interface CommentCategoryMapper extends BaseMapper<CommentCategory> {

    //查询全部的分类
    List<CommentCategory> selectAllCommentCategory();

    //查询人生帖子的数量
    Integer selectCountRenShen();

    //查询事业帖子的数量
    Integer selectCountShiYe();

    //查询爱情帖子的数量
    Integer selectCountAiQing();

    //查询友情帖子的数量
    Integer selectCountYouQing();

    //查询亲情帖子的数量
    Integer selectCountQinQing();
}
