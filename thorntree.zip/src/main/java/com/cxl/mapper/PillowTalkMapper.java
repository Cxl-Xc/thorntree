package com.cxl.mapper;

import com.cxl.entity.Po.PillowTalk;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-19
 */
public interface PillowTalkMapper extends BaseMapper<PillowTalk> {

    //根据like和page查询信息
    List<PillowTalk> selectPillowTalkByLike(String like, Integer page2);

    //查询全部帖子数量
    Integer selectPillowTalkCountByLike(String like);
}
