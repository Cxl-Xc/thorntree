package com.cxl.mapper;

import com.cxl.entity.Dto.CommentDot1;
import com.cxl.entity.Dto.CommentDto;
import com.cxl.entity.Po.Comment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cxl.entity.Po.CommentAddress;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
public interface CommentMapper extends BaseMapper<Comment> {

    //根据类别名字查询是否有这个类别 返回类别Id
    Integer selectCommentCategoryIdByCommentCategoryName(String commentCategoryName);

    //向commentAddress表插入数据
    void insertIntoCommentAddress(Integer commentId, String name);

    //查询全部帖子 分页显示
    List<CommentDto> selectAllCommentByPage(Integer page2);

    //根据帖子Id查询commentAddress
    List<CommentAddress> selectCommentAddress(Integer commentId);

    //根据commentCategoryId查询commentCategoryName
    String selectCommentCategoryNameBycommentCategoryId(Integer commentCategoryId);

    //查询该用户点赞的所有帖子的id
    List<Integer> selectUserLikeCommentId(Integer userId);

    //查询全部帖子的数量
    Integer selectCountComment();

    //根据类别查询帖子 分页显示
    List<CommentDto> selectCommentByCommentCategoryIdAndPage(Integer page2, Integer commentCategoryId);

    //查询全部类别帖子的数量
    Integer selectCountCommentByCommentCategoryId(Integer commentCategoryId);

    //根据commentTitle查询全部comment信息 分页显示
    List<CommentDto> selectCommentByLikeTitleAndPage(String commentTitle, Integer page2);

    //根据commentTitle查询到所有帖子的数量
    Integer selectCountCommentByLikeCommentTitle(String commentTitle);

    //根据userId查询该用户发布的帖子 分页显示
    List<CommentDto> selectCommentByUserIdAndPage(Integer userId, Integer page2);

    //根据userId查询全部帖子的数量
    Integer selectCountCommentByUserId(Integer userId);

    //根据userId查询用户喜欢的帖子的id
    List<Integer> selectLikeCommentByUserId(Integer userId, Integer page2);

    //根据commentId查询comment
    CommentDto selectCommentByCommentIdForLikes(Integer commentId);

    //根据userId查询全部喜欢的帖子的数量
    Integer selectCountCommentByUserIdLike(Integer userId);

    //用户自己删除帖子
    void updateCommentStateByUserId(Integer userId, Integer commentId);

    //删除帖子下面的评论
    void updateCommentSonStateByCommentId(Integer commentId);

    //删除这个喜欢这个帖子的全部信息
    void updateLikesByCommentId(Integer commentId);

    //根据commentId查询comment
    List<CommentDto> selectCommentByCommentId(Integer commentId);

    //修改帖子的state为2
    void updateCommentStateByTo2(Integer commentId);

    //修改likes表下的state为1
    void updateLikesStateByCommentId(Integer commentId);

    //修改帖子的state为0
    void updateCommentStateByTo0(Integer commentId);

    //查询全部下架帖子的数量
    Integer selectCounts();

    //根据帖子id查询评论数量 浏览数量 喜欢数量
    CommentDot1 selectLikesAndCommentsAndSawByCommentId(Integer commentId);

    //根据id查询下架帖子
    List<CommentDto> selectCommentByCommentIdAndStateIs2(Integer commentId);
}
