package com.cxl.hander;



import com.alibaba.fastjson.JSON;

import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Component;

import java.util.Map;

//获取微信token
@Component
public class GetDetailByUrl {
    public  Map<String,Object> getDetailByUrl() {
        Map<String, Object> map = null;
        String access_token_url = "https://api.weixin.qq.com/cgi-bin/token?" +
                "grant_type=client_credential" +
                "&appid=wx2bcb898c76a62fc6"+
                "&secret=0f48216b3ec234095ecc357ac7f6c187";
        try {
            HttpClient client = HttpClientBuilder.create().build();//构建一个Client
            HttpGet get = new HttpGet(access_token_url.toString());    //构建一个GET请求
            HttpResponse response = client.execute(get);//提交GET请求
            HttpEntity result = response.getEntity();//拿到返回的HttpResponse的"实体"
            String content = EntityUtils.toString(result);

            //将json转化为map
            map = JSON.parseObject(content,Map.class);

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("获取信息失败");
        }
        return map;
    }
}