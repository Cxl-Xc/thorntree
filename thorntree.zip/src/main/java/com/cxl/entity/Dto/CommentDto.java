package com.cxl.entity.Dto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.cxl.entity.Po.CommentAddress;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CommentDto implements Serializable {



    /**
     * 帖子Id
     */
    @TableId(value = "commentId", type = IdType.AUTO)
    private Integer commentId;

    /**
     * 上传者Id
     */
    @TableField("userId")
    private Integer userId;

    private String username;

    /**
     * 帖子标题
     */
    @TableField("commentTitle")
    private String commentTitle;

    /**
     * 帖子内容
     */
    @TableField("commentText")
    private String commentText;

    /**
     * 上传时间
     */
    @TableField("commentTime")
    private Date commentTime;

    /**
     * 点赞人数
     */
    private String likes;

    /**
     * 多少人看过
     */
    private String saw;

    /**
     * 评论数
     */
    private String comments;

    /**
     * 状态 0是有 1是无
     */
    private String state;

    /**
     * 评论类别Id
     */
    @TableField("commentCategoryId")
    private Integer commentCategoryId;

    private String commentCategoryName;

    private List<CommentAddress> commentAddress;

    private String userPortraitAddress;


}
