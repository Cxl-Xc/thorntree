package com.cxl.entity.Dto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class UserDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 用户Id
     */
    @TableId(value = "userId", type = IdType.AUTO)
    private Integer userId;

    /**
     * 用户名  可用于账号登录的账号
     */
    private String username;

    /**
     * 密码  要MD5加密
     */
    private String password;

    /**
     * 用户状态   0代表有  1代表无
     */
    private String state;

    /**
     * 用户绑定邮箱  一个邮箱可以绑定多个账号
     */
    private String email;

    /**
     * 判断用户登录状态
     */
    private String token;


    private String userPortraitAddress;


    private String userRole;

    private String openId;


}
