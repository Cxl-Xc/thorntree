package com.cxl.entity.Bo;

import lombok.Data;
//获取微信授权登录的code
@Data
public class LoginBo {
    private String code;
//    private String username;
//    private String userPortraitAddress;

}
