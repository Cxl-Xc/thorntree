package com.cxl.entity.Vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)

public class CommentSonVo implements Serializable {


    /**
     * 评论者Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 父帖子Id
     */
    @TableField("commentId")
    private Integer commentId;

    /**
     * 评论
     */
    @TableField("commentSonText")
    private String commentSonText;

    /**
     * 评论者token
     */

    private String token;



}
