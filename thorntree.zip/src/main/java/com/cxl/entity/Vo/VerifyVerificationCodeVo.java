package com.cxl.entity.Vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class VerifyVerificationCodeVo implements Serializable {



    /**
     * 用户绑定邮箱  一个邮箱可以绑定多个账号
     */
    private String email;

    /**
     * 判断用户登录状态
     */
    private Integer msg;


}
