package com.cxl.entity.Vo;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 *
 * </p>
 *
 * @author itcast
 * @since 2022-05-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class LikesVo implements Serializable {


    /**
     * 用户Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 帖子Id
     */
    @TableField("commentId")
    private Integer commentId;


    private String token;


}
