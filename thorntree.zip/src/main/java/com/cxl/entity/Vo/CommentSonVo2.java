package com.cxl.entity.Vo;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)

public class CommentSonVo2 implements Serializable {


    /**
     * 用户Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 评论Id
     */

    private Integer commentSonId;


    /**
     * 评论者token
     */

    private String token;



}
