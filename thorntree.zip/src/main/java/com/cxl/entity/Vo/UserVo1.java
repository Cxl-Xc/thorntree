package com.cxl.entity.Vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class UserVo1 implements Serializable {



    /**
     * 用户Id
     */

    private Integer userId;

    /**
     * 用户名  可用于账号登录的账号
     */
    private String newUsername;

    /**
     * 判断用户登录状态
     */
    private String token;


}
