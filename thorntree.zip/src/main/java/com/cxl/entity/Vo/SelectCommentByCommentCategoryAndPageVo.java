package com.cxl.entity.Vo;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class SelectCommentByCommentCategoryAndPageVo implements Serializable {

    private Integer userId;

    private Integer page;

    private String commentCategoryName;


}
