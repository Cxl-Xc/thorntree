package com.cxl.entity.Po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("commentSon")
public class CommentSon implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 帖子评论Id
     */

    @TableId(value = "commentSonId", type = IdType.AUTO)
    private Integer commentSonId;

    /**
     * 评论者Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 父帖子Id
     */
    @TableField("commentId")
    private Integer commentId;

    /**
     * 评论
     */
    @TableField("commentSonText")
    private String commentSonText;

    /**
     * 状态 0有1无
     */
    private String state;

    /**
     * 评论时间
     */
    @TableField("commentSonDate")
    private Date commentSonDate;


}
