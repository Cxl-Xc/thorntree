package com.cxl.entity.Po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("commentAddress")
public class CommentAddress implements Serializable {


    /**
     * 评论Id
     */
    @TableField("commentId")
    private Integer commentId;

    /**
     * 评论图片地址
     */
    @TableField("commentAddress")
    private String commentAddress;


}
