package com.cxl.entity.Po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Article implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 文章Id
     */
    @TableId(value = "articleId", type = IdType.AUTO)
    private Integer articleId;

    /**
     * 上传者Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 文章标题
     */
    @TableField("articleTitle")
    private String articleTitle;

    /**
     * 文章内容
     */
    @TableField("articleText")
    private String articleText;

    /**
     * 上传文章时间
     */
    @TableField("articleTime")
    private Date articleTime;

    /**
     * 点赞数量
     */
    private String likes;

    /**
     * 浏览量
     */
    private String saw;

    /**
     * 状态  0 有 1 无
     */
    private String state;


}
