package com.cxl.entity.Po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("pillowTalk")
public class PillowTalk implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 悄悄话Id
     */
    @TableId(value = "pillowTalkId", type = IdType.AUTO)
    private Integer pillowTalkId;

    /**
     * 悄悄话暗号
     */
    @TableField("pillowTalkKey")
    private String pillowTalkKey;

    /**
     * 悄悄话内容
     */
    @TableField("pillowTalkText")
    private String pillowTalkText;

    /**
     * 上传者Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 0有1无
     */
    private String state;

    /**
     * 上传时间
     */
    private Date time;


}
