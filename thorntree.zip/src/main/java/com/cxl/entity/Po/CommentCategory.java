package com.cxl.entity.Po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("commentCategory")
public class CommentCategory implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 评论类别Id
     */
    @TableField("commentCategoryId")
    private Integer commentCategoryId;

    /**
     * 类别名称
     */
    @TableField("commentCategoryName")
    private String commentCategoryName;

    /**
     * 状态 0有 1无
     */
    private String state;


}
