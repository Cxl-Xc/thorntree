package com.cxl.entity.Po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Comment implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 帖子Id
     */
    @TableId(value = "commentId", type = IdType.AUTO)
    private Integer commentId;

    /**
     * 上传者Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 帖子标题
     */
    @TableField("commentTitle")
    private String commentTitle;

    /**
     * 帖子内容
     */
    @TableField("commentText")
    private String commentText;

    /**
     * 上传时间
     */
    @TableField("commentTime")
    private Date commentTime;

    /**
     * 点赞人数
     */
    private String likes;

    /**
     * 多少人看过
     */
    private String saw;

    /**
     * 评论数
     */
    private String comments;

    /**
     * 状态 0是有 1是无
     */
    private String state;

    /**
     * 评论类别Id
     */
    @TableField("commentCategoryId")
    private Integer commentCategoryId;


}
