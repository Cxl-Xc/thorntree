package com.cxl.entity.Po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2023-03-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("userFeedBack")
public class UserFeedBack implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 用户ID
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 用户反馈
     */
    @TableField("feedBack")
    private String feedBack;

    /**
     * 用户反馈
     */
    @TableId(value = "userBackId", type = IdType.AUTO)
    @TableField("userBackId")
    private Integer userBackId;


}
