package com.cxl.entity.Po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Likes implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 点赞Id
     */
    @TableId(value = "likesId", type = IdType.AUTO)
    private Integer likesId;

    /**
     * 点赞用户Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 点赞帖子Id
     */
    @TableField("commentId")
    private Integer commentId;

    /**
     * 状态 0有1无
     */
    private String state;

    /**
     * 最后一次点赞的时间
     */
    @TableField("lastLikeTime")
    private LocalDateTime lastLikeTime;


}
