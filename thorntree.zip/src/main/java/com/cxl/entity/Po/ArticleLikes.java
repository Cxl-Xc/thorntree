package com.cxl.entity.Po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author itcast
 * @since 2022-06-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("articleLikes")
public class ArticleLikes implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 点赞文章Id
     */
    @TableId(value = "articleLikesId", type = IdType.AUTO)
    private Integer articleLikesId;

    /**
     * 点赞用户Id
     */
    @TableField("userId")
    private Integer userId;

    /**
     * 被点赞的文章Id
     */
    @TableField("articleId")
    private Integer articleId;

    /**
     * 状态 0 有1 无
     */
    private String state;

    /**
     * 最后点赞的时间
     */
    @TableField("lastLikeTime")
    private Date lastLikeTime;


}
